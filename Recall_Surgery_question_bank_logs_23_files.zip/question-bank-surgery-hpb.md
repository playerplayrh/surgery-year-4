# Question bank — Gallstone Disease & MIS (Vacharathit) (Recall Surgery)

Source: "Gallstone Diseases & Minimally Invasive Surgery" lecture, Voranaddha Vacharathit (Asst. Prof. of Surgery), 7-page handout with handwritten annotations, plus the web-verified Ultimate Summary PDF built from it (Oct 2026).
Target: Notion data source `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-14. Topic prefix: `Gallstone-MIS (Vacharathit) · ChN …`. No `Source` URL (no Notion page for the slides).

## Counts (verified by SQL after upload)

| Type | n |
|---|---|
| MCQ | 28 |
| Flashcard | 26 |
| MEQ | 2 |
| OSCE | 3 |
| **Total** | **59** |

| Chapter (Topic) | Subject | n |
|---|---|---|
| Ch1 Gallstone disease | Hepatobiliary & Pancreas (HPB) | 44 (MCQ 21 · FC 19 · MEQ 1 · OSCE 3) |
| Ch2 Minimally invasive surgery | General surgery | 15 (MCQ 7 · FC 7 · MEQ 1) |

OSCE stations: focused RUQ exam incl. Murphy's sign (7 min) · informed consent for LC (7 min) · POD2 post-LC worsening pain + fever (8 min).
MEQs: Reynolds pentad / TG18 grade III cholangitis → ERCP → same-admission LC → post-ERCP pancreatitis · LC in a cardiac patient: pneumoperitoneum physiology → CO2 embolism → conversion → shoulder-tip pain vs missed bowel injury.
MCQ key spread: A 6 · B 5 · C 6 · D 5 · E 6. Integrity: all MCQs have 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; 0 duplicate Names; all `Status = Ready`.

## Editorial rules applied
- MCQ fully English, vignettes 343–478 chars with vitals; lead-ins weighted to decisions (operate vs drain vs ERCP, timing, bail-out, post-op POD).
- Flashcards ≤3 lines / ≤350 chars, Thai structure + English terms.
- No drug doses anywhere. Guidelines keyed to TG18 (cholecystitis/cholangitis), ASGE 2019 (choledocholithiasis), PONCHO/APEC (biliary pancreatitis), CHOCOLATE, SAGES Safe Cholecystectomy (CVS, bail-out).
- Lecturer's handwritten emphasis used as item material (normal LFT in cholecystitis, "white bile" hydrops, primary CBD stone = brown, "ไม่ผ่า" in pancreatitis, PCD for unfit patients, CO↓/HR↔/PCWP↑).
- Large-stone cut-off not tested (slide 2–3 cm vs literature >3 cm). HIDA used only as a distractor (rarely available in Thailand).

## What verification changed
Independent reviewer answered all 28 MCQs blind — 100% agreement with keys. 24 scripted fixes:
- Must-fix: cholangitis item said "cardiovascular dysfunction" without a vasopressor → TG18 grade III reasoning corrected (neurological; CV only once vasopressor needed).
- Porcelain GB stem: removed "diffuse" (diffuse intramural calcification carries lower cancer risk than selective mucosal); explanation nuanced.
- Mild biliary pancreatitis stem now states no organ failure (PONCHO population).
- ERCP timing claims softened to "observational data, earlier (24–48 h)" in MCQ and MEQ.
- Removed the only dose-like number (dopamine threshold) from the TG18 grade III flashcard.
- OSCE POD2 checklist: CT only when hemodynamically stable; consent checklist gained recovery-expectations item.
- MIS MEQ no longer introduces a second patient; CO2 embolism positioning made explicit (left lateral decubitus, head-down).
- "Calot" removed from hepatocystic-triangle card; POEM card clarified (submucosal lift).
- Four MCQs with length-cued keys shortened.

## Known gaps — deliberately not tested
- Antibiotic choice/dose and post-LC antibiotic duration for grade III (TG18 source unclear).
- AAC mortality figures; Strasberg B–D detail and E1–E5 levels.
- Port sizes/placement, Hasson vs Veress, drains, one- vs two-stage gallstone ileus repair, insufflation pressure value (practice variation).
- MIS: CO2 embolism thresholds, capnothorax drain criteria, subcutaneous emphysema, port-site hernia closure size, pregnancy — not established by the source.
- The lecture does not teach peri-op care beyond MIS physiology; peri-op items rest on the verified fact sheet (SAGES).
- Near-duplicate pairs to watch: cholangitis MCQ ↔ cholangitis MEQ; CO2 embolism MCQ ↔ MIS MEQ; bile-leak MCQ ↔ POD2 OSCE.

## Retiring this set
Rows were created after `2026-10-14 02:26:23Z`; filter `Topic LIKE 'Gallstone-MIS%'`. MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

---

# Question bank — Liver Disease (Taesombat) (Recall Surgery)

Source: "Liver disease" lecture, Wipusit Taesombat MD (Dept. of Surgery, Chula), 118 slides with handwritten annotations + Kahoot answers, plus the web-verified Ultimate Summary PDF built from it (Liver_Disease_Surgical_Summary.pdf, Oct 2026).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-14 (rows created 07:12:29Z–07:12:45Z). Topic prefix: `Liver Disease (Taesombat) · ChN …`. Subject = Hepatobiliary & Pancreas (HPB) for every item. No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Anatomy & liver function | 6 | 7 | 1 | 1 | 15 |
| Ch2 Liver abscess | 8 | 6 | 1 | 0 | 15 |
| Ch3 Cystic lesions | 6 | 6 | 1 | 0 | 13 |
| Ch4 Benign solid tumors | 7 | 6 | 1 | 1 | 15 |
| Ch5 Malignant tumors | 8 | 7 | 1 | 1 | 17 |
| **Total** | **35** | **32** | **5** | **3** | **75** |

OSCE stations (8 min each): POD4 review after right hepatectomy (bile leak / PHLF / glucose-phosphate / VTE) · counselling a woman on OCP with hepatic adenoma (EASL 2016) · counselling an HBV carrier on HCC surveillance.
MEQs: HCC on HBV cirrhosis → Child-Pugh/ICG/Makuuchi/FLR/PVE → extent → ISGLS complication · diabetic elderly septic PLA from cholangitis → resuscitation → antibiotic + PCD + ERCP · hydatid cyst → WHO-IWGE → PAIR vs surgery → albendazole + principles → complication · ruptured HCA in OCP user → resuscitation → TAE → EASL follow-up · surveillance-detected HCC → no-biopsy diagnosis → BCLC → resection vs LT → follow-up.
MCQ key spread: A 7 · B 6 · C 7 · D 7 · E 8. Stems 343–522 chars, all with vitals. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names in the DB; all `Status = Ready`.

## Editorial rules applied
- MCQ fully English; lead-ins weighted to decisions (drain vs antibiotics vs ERCP, observe vs resect, PAIR vs surgery, resection vs LT vs ablation vs TACE, extent of hepatectomy by Makuuchi).
- No drug doses anywhere (drug names only). Lab values in stems are not doses.
- Frameworks named when the answer depends on them: Makuuchi (Kokudo 2015 description), ISGLS bile leak & PHLF, Child-Pugh, WHO-IWGE, BCLC 2022, Milan, AASLD 2023, EASL 2016, CDC echinococcosis.
- Slide vs guideline conflicts handled by framing: HCA size cut-off only as "EASL 2016 (5 cm)"; "most common organism/route" framed as lecture/Western vs Asian (Klebsiella, cryptogenic).
- Lecturer's emphasis (Kahoot) used as item material: "only portal flow" is NOT true; PLA = antibiotic + drainage; asymptomatic simple cyst = observe; hemangioma = most common benign tumor; HBV carrier = all of follow-up/screening/antiviral; screening indication = cirrhosis + HBV carrier.

## What verification changed
Independent reviewer answered all 35 MCQs blind — 35/35 agreed with keys. 22 scripted fixes applied:
- MUST-FIX: hepatectomy MEQ diagnosed PHLF on POD 3 → moved to POD 5 and tied to the ISGLS definition.
- ALA "failed medical therapy" stem changed from day 5 to day 7 (removes a defensible "continue" option; slide 3–4 d vs StatPearls 5–7 d now stated on the flashcard).
- "Most common route of PLA" framed as lecture/Western in 3 items (cryptogenic Klebsiella commoner in Asian series).
- AASLD 2023 surveillance = ultrasound **plus** AFP q6mo (slide wrote US ± AFP) — corrected in MCQ and OSCE.
- Bleeding HCA: resection now conditional on residual viable lesion on follow-up imaging (EASL), not automatic.
- Hydatid: CDC vs WHO-IWGE attributions separated; CE2 MCQ explanation adds the >7.5 cm CDC basis.
- Minor: cryoprecipitate distractor rationale, β-catenin attribution (EASL vs Nault), MCN naming removed (unverified), BCLC 0–A wording, LT extended-criteria nuance, one lead-in reworded.
- Not applied: reviewer suggested Makuuchi bilirubin bands from memory (≥2.0 no resection; 1.1–1.5 / 1.6–1.9) — conflicts with the web-verified source used (Kokudo 2015: >2.0 no; 1–2.0 limited). Kept the verified version; worth re-checking against the original 1993 paper.

## Known gaps — deliberately not tested
- Antibiotic regimens/doses and durations beyond naming drugs; melioidosis treatment; colonoscopy after cryptogenic PLA.
- Bismuth-Corlette types, MCN details, aspiration-sclerotherapy, Thai iCCA proportions, ruptured-HCC sequence (flagged unverified/principle-only in the summary).
- HCA molecular subtype percentages (slide figures sum >100%).
- Practice variation: drains, Pringle timing, margin width, pre-op biliary drainage, ERAS drain policy.
- The lecture itself has no peri-op or complication content; Ch1 peri-op/ISGLS items rest on the web-verified summary.
- Near-duplicate pairs to watch: PHLF MCQ ↔ Ch1 MEQ Q5; CE2 MCQ ↔ hydatid MEQ; HCA-on-OCP MCQ ↔ HCA OSCE; ruptured HCA MCQ ↔ Ch4 MEQ; HBV surveillance MCQ ↔ HBV OSCE; no-biopsy MCQ ↔ Ch5 MEQ.

## Retiring this set
Filter `Topic LIKE 'Liver Disease (Taesombat)%'` (rows created 2026-10-14 07:12:29Z–07:12:45Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

---

# Question bank — Approach to Liver Mass (Vorasittha/Sirichindakul) (Recall Surgery)

Source: "Approach to Liver mass" lecture, Athaya Vorasittha / Boonchoo Sirichindakul (Dept. of Surgery, Chula), 68 slides incl. radiology handout pages with handwritten annotations, plus the web-verified Ultimate Summary PDF built from it (approach_to_liver_mass_summary.pdf, Oct 2026).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-14 (rows created from 07:20:42Z). Topic: `Approach to Liver Mass (Vorasittha/Sirichindakul)` (single chapter). Subject = Hepatobiliary & Pancreas (HPB) for every item. No `Source` URL.

## Counts (verified by SQL after upload)

| Type | n |
|---|---|
| MCQ | 22 |
| Flashcard | 22 |
| MEQ | 1 |
| OSCE | 3 |
| **Total** | **48** |

OSCE stations: focused abdominal exam for a liver mass (7 min) · counselling a woman on OCP with a 3.5-cm hepatic adenoma (ACG 2024 follow-up) (8 min) · POD5 post-right-hepatectomy review, rising bilirubin/INR + bilious drain (8 min).
MEQ: HBV cirrhosis on US + AFP surveillance → new 3-cm lesion → triple-phase CT / LI-RADS → staging, liver reserve, FLR → resection → POD3 bile leak vs POD5 PHLF.
MCQ key spread: A 4 · B 5 · C 4 · D 5 · E 4. Stems 200–550 chars with vitals; no key >1.5× median option length. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names in the DB (520 rows); all `Status = Ready`.

## Editorial rules applied
- MCQ fully English; lead-ins weighted to decisions: no-biopsy LR-5 vs LR-4 work-up, LI-RADS applicability, observe vs resect (hemangioma, adenoma by sex/size), ruptured tumour → resuscitate + TAE, cyst observe vs fenestration vs resection (MCN), hydatid albendazole + PAIR/surgery, amebic vs pyogenic vs melioidosis abscess, CCA work-up with CA 19-9 caveat, CRLM no-biopsy, PVE for small FLR, biopsy when it changes management, BCLC B → TACE, first-line systemic (AASLD 2023), PHLF vs bile leak (ISGLS).
- Slide corrections keyed to the guideline: LI-RADS 5 ≥20 mm (slide "≥2 mm"); 10–19 mm APHE + washout alone = LR-5, APHE + capsule alone = LR-4 (slide "all of the following"); sorafenib replaced by atezolizumab-bevacizumab / durvalumab-tremelimumab.
- No drug doses. Child-Pugh point values and Milan criteria not used as keys (unverified in the summary). Slide-only numbers (marker accuracy table, Takamori 5.1%, TACE 3-yr survival, NET debulking %, gadobenate timing) used only as attributed flashcard facts, never MCQ keys.

## What verification changed
Independent reviewer answered all 22 MCQs blind — 22/22 agreed with keys. 19 scripted fixes across 12 items:
- BCLC B stem now states well-defined nodules with preserved portal flow (removed a defensible systemic-therapy option).
- Hydatid stem: mixed CE stages (calcified wall + daughter cysts) replaced by water-lily sign; "observation" distractor rationale tied to CE4/CE5.
- Amebic abscess: 6 cm → 4 cm (size alone arguably justifies aspiration); non-response window noted as 48–72 h to 5–7 days by source.
- CCA stem gained "no chronic liver stigmata, HBsAg/anti-HCV negative" (explanation relied on it); hemangioma stem gained HBsAg negative (ACG: no follow-up unless cirrhosis/HBV).
- Adenoma OSCE: surgery criterion fixed for a 3.5-cm lesion (grows to ≥5 cm or complication); follow-up = imaging q6mo × 2 y then yearly (ACG 2024).
- Echinococcus serology = antibody ELISA, not antigen (slide wrote "Ag") — fixed in MCQ, flashcard and the summary PDF.
- PIVKA-II card notes false positives with vitamin K deficiency/warfarin; sulfur-colloid card "FNH ส่วนใหญ่ติด"; LI-RADS card adds exclusions (age <18, vascular-disorder/congenital hepatic fibrosis cirrhosis); "excludes bile leak" softened to "argues strongly against".
- Summary PDF also corrected: HCC surveillance = US **plus** AFP q6mo (AASLD 2023), matching the Taesombat set.

## Known gaps — deliberately not tested
- Child-Pugh point cut-offs, Milan criteria, ICG-R15 thresholds, Makuuchi criteria (not in this lecture / unverified in the summary).
- Antibiotic regimens and doses for pyogenic and melioidosis abscess; albendazole/metronidazole dosing.
- Operative technique detail (Pringle timing, margin width, drains, open vs laparoscopic choice) — practice variation; only Pringle contents tested.
- CCA anatomic distribution in Thailand (slide gives Western proportions; Thai iCCA share unverified); Bismuth-Corlette not taught.
- The lecture has no peri-op or complication content; PHLF / bile-leak items rest on the web-verified summary (ISGLS).
- Overlap with the Taesombat "Liver Disease" set (same Subject): adenoma-on-OCP OSCE, ruptured tumour → TAE, hydatid PAIR, amebic abscess, PHLF/bile-leak POD review, LR-5 no-biopsy. Different lecture and Topic, so kept; filter by Topic if drilling one lecture.
- Within-set near-duplicates: adenoma MCQ ↔ adenoma OSCE; PHLF MCQ ↔ MEQ Q5 ↔ POD5 OSCE; FLR MCQ ↔ FLR flashcard ↔ MEQ Q3.

## Retiring this set
Filter `Topic = 'Approach to Liver Mass (Vorasittha/Sirichindakul)'` (rows created from 2026-10-14 07:20:42Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

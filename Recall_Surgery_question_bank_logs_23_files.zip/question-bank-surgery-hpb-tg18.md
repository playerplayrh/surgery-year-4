# Question bank — Tokyo Guidelines 2018 (TG18) (Recall Surgery)

Source: the web-verified "Tokyo Guidelines 2018 (TG18)" Ultimate Summary PDF (Tokyo_Guidelines_TG18_Summary.pdf, 3 chapters, Oct 2026), itself built from the TG18 papers in JHBPS 2018 (Okamoto, Miura, Gomi, Mukai 2017, Mori, Wakabayashi, Kiriyama/Yokoe) + CHOCOLATE (Loozen BMJ 2018). As of Oct 2026 no Tokyo Guidelines edition newer than TG18 was found.
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-21 (rows created 02:05:49Z–02:06:10Z). Subject = Hepatobiliary & Pancreas (HPB) for every item. `Source` = the TG18 paper URL per chapter (Ch1 jhbp.518 Gomi · Ch2 jhbp.509 Miura · Ch3 jhbp.516 Okamoto).
Companion to the other HPB sets in `claude/question-bank-surgery-hpb.md` — written to **avoid duplicating** the 98 existing gallstone/cholangitis items (Vacharathit Ch1, Tiger sum GS7 Ch2/Ch3, Board review UGI-MIS Ch12).

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Tokyo Guidelines TG18 · Ch1 Overview, initial management & antimicrobials | 6 | 6 | 1 | 1 | 14 |
| Tokyo Guidelines TG18 · Ch2 Acute cholangitis | 8 | 6 | 1 | 0 | 15 |
| Tokyo Guidelines TG18 · Ch3 Acute cholecystitis | 8 | 6 | 1 | 1 | 16 |
| **Total** | **22** | **18** | **3** | **2** | **45** |

MCQ key spread: A 5 · B 5 · C 4 · D 4 · E 4. Stems 380–545 chars, all with vitals. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes (8); all non-MCQ have Answer; all `Status = Ready`; 0 duplicate Names in the DB (2,260 rows).

OSCE stations: admission/initial orders for suspected grade II cholangitis at a community hospital (culture before antibiotic, timing, grading, CCI/ASA-PS, transfer) · counselling the daughter of a CCI 7/ASA IV patient with grade II cholecystitis failing antibiotics about PTGBD.
MEQs: hospital-onset grade II cholangitis → HCAI regimen → staged stones → liver abscess duration · hilar malignant obstruction (liver-fluke context) → definite Dx without Charcot → early drainage → undrained segments · grade III cholecystitis with reversible CV/renal failure (FOSF), no NPF → early LC → CVS/R4U/bail-out → POD0 bleeding.

## Angles deliberately chosen (TG18-specific, not in existing sets)
- Ch1: antibiotics now (≤6 h) even with ERCP booked tomorrow; stop ≤24 h after LC for grade I–II; 4–7 d when gangrene/perforation found; HCAI = anti-pseudomonal + vancomycin; metronidazole with biliary-enteric anastomosis; grade I + CBD stone at a no-drainage hospital → transfer; ERCP prophylaxis removed; blood/bile culture rules.
- Ch2: definite Dx without Charcot (B-2 counts); suspected → MRCP not diagnostic ERCP; grade III from platelets alone in a normotensive alert patient; DOAC with normal INR → stent/ENBD, no EST, staged; large/multiple stones staged; Roux-en-Y → BE-ERCP → EUS-BD/PTBD; stent occlusion.
- Ch3: FOSF (renal only) → early LC; FOSF + respiratory NPF → PTGBD; grade I high-risk → antibiotics then delayed LC; grade II low-risk at 2 am → daytime-list LC ("early" ≠ after-hours); EUS-GBD/ETGBD limited to high-volume centres; emphysematous = grade II not III; suspected vs definite; LC timing after PTGBD = no consensus.

## What verification changed
Independent reviewer answered all 22 MCQs blind — 21/22 agreed; the one disagreement (grade I + CBD stone → transfer) was adjudicated in favour of the key (Miura 2018). No wrong keys, no doses. 17 scripted fixes:
- MUST-FIX: CCI in 5 stems (3 MCQ, MEQ, OSCE) did not match the listed comorbidities — Okamoto's CCI is the original Charlson **without age points**; comorbidities added so each sum equals the stated CCI.
- MUST-FIX: OSCE checklist rewarded "grade II" without lab data → reworded to "grade once labs/US available (needs ≥2 of 5)".
- Validation flashcard: kept sensitivity 87.6%/specificity 77.7% (TG13 cholangitis paper, Kiriyama 2013 abstract — the reviewer could not reach it but it was verified earlier); dropped the "~12% false positive in cholecystitis" figure, which belongs to TG07/Charcot data.
- Grade I + CBD stone = manage like grade II made consistent across MCQ, flashcard and a second MCQ explanation (Miura 2018 "should be considered").
- "Non-operated" removed from the pericholecystic abscess/perforation duration rule (not in Gomi 2018); perforation MCQ explanation now mentions the clinical endpoint too.
- CHOCOLATE inclusion = APACHE-II 7–14 (not ≥7). The CHOCOLATE flashcard was then replaced (duplicated existing Vacharathit MCQ) with an ETGBD-technique card.
- Early-LC-after-hours MCQ rewritten from a grade I patient (near-duplicate of existing Vacharathit item) to a low-risk grade II patient (WBC >18,000).
- Roux-en-Y explanation notes US practice (laparoscopy-assisted ERCP) vs TG18/NL (BE-ERCP); bile-culture card wording tightened; one MEQ line relabelled [หลักการ].
- Same fixes carried into the summary PDF, plus: PDF board Q4 had "warfarin INR 2.8 = moderate" — INR >1.5 is a grade III criterion; changed to apixaban with INR 1.1 and added the warning.

## Known gaps — deliberately not tested
- Antibiotic-to-grade pairing beyond the source table (summary warns to check Gomi Table 3); any doses.
- GB wall thickness cut-offs, ERCP complication rates, timing of LC after PTGBD beyond "no consensus".
- Subtotal / fundus-first details (principle-level only); drains and diet start (practice variation).
- Borderline CCI/ASA values ("and" vs "and/or" wording differs between Okamoto figure and abstract).

## Cross-bank issue to review (not changed)
- Existing Tiger sum GS7 Ch3 MCQ (post-Whipple hepaticojejunostomy stricture, keyed PTBD) says PTBD is the route "when anatomy is altered" — TG18 (Mukai 2017) makes BE-ERCP first-line where expertise exists. Explanation should say PTBD is for when BE-ERCP expertise is lacking.

## Near-duplicates to watch
- Within set: FOSF MCQ ↔ Ch3 MEQ; high-risk grade II PTGBD MCQ ↔ PTGBD OSCE; PTGBD counselling MCQ ↔ "LC after PTGBD" flashcard; HCAI MCQ ↔ Ch1 MEQ Q3.
- Against existing: emphysematous-is-grade-II MCQ ↔ existing grade II flashcards (kept: adds the "diabetes is not organ dysfunction" trap).

## Retiring this set
Filter `Topic LIKE 'Tokyo Guidelines TG18%'` (rows created from 2026-10-21 02:05:49Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

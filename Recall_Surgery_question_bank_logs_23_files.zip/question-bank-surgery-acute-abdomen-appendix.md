# Question bank — Acute abdomen & Appendix (อ.สุกัญญษ) (Recall Surgery)

Source: lectures 13.1 "Acute abdomen" (80 slides) and 13.2 "Appendix" (45 slides), both with handwritten lecturer annotations (decoded), plus the web-verified Ultimate Summary PDF built from them (Acute_Abdomen_and_Appendicitis_Summary.pdf, Oct 2026).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-21 (rows created 01:51:43Z–01:52:00Z). Subject = General surgery for every item. No `Source` URL. Lecturer name in Topic is exactly as the user typed it (อ.สุกัญญษ).

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Acute abdomen & Appendix (อ.สุกัญญษ) · Ch1 Acute abdomen | 9 | 9 | 1 | 2 | 21 |
| Acute abdomen & Appendix (อ.สุกัญญษ) · Ch2 Acute appendicitis | 9 | 8 | 1 | 1 | 19 |
| **Total** | **18** | **17** | **2** | **3** | **40** |

OSCE: history taking in acute abdominal pain · pre-op order for perforated PU before transfer (drug classes only; UO ≥0.5 mL/kg/h from summary) · counselling NOM of appendiceal mass.
MEQs: 72M AF, embolic mesenteric ischemia → resuscitation → CTA → laparotomy/damage control → POD1 relook · 82M perforated appendicitis + generalized peritonitis + septic hypotension → no CT in shock → lower midline + washout → class IV wound, 2–3 d Abx → POD6 abscess → CT + PCD.
MCQ key spread: A 3 · B 4 · C 4 · D 4 · E 3. Integrity: all MCQs 5 choices + Correct + Explanation; OSCEs Checklist + Minutes; non-MCQ all Answer; 0 duplicate Names in DB (2,215 rows); all Ready.

## Editorial rules applied
- MCQ fully English, stems 344–470 chars with vitals; lead-ins on decisions: pneumonia mimic → CXR; stable PPU with negative CXR → CT (free air ~75%); adhesive SBO with strangulation signs → laparotomy; rectus sheath hematoma (Carnett); uncertain dx → active observation, never "malingering"; peritonitis + free air in shock → midline laparotomy; high-risk empyema GB → percutaneous cholecystostomy; gallstone ileus (pneumobilia without ERCP); retroperitoneal duodenal perforation; Alvarado 10 with sterile pyuria → appendectomy; gastroenteritis pattern → rehydrate/re-examine; POD5 SSI → open & drain; US not seen + fluid → CT; >80 y atypical → contrast CT; prophylaxis for 128 kg (cefazolin 3 g + metronidazole); POD0 mesoappendix bleed unstable → OR; appendicolith → appendectomy over antibiotics (CODA); POD8 stump-leak fistula without sepsis → conservative.
- Only dose used: summary-verified prophylaxis (cefoxitin 2 g or cefazolin 2 g/3 g ≥120 kg + metronidazole 500 mg IV ≤60 min pre-incision) with formulary caveat.
- Lecturer numbers used as "ตามสไลด์": free air 75%, adhesive SBO 80% resolve, negative appendectomy 16%, epidemiology, special-population figures.

## What verification changed
Blind reviewer answered all 18 MCQs — 18/18 matched keys. Applied by scripted replacement:
- MUST: CODA 20.2 vs 3.6/100 re-attributed correctly (antibiotics vs appendectomy among appendicolith patients; the summary PDF's wording of this line is ambiguous); LBO card now excepts sigmoid volvulus without gangrene (endoscopic decompression first); AMI MEQ: removed inapplicable anticoagulant line, added immediate IV UFH flagged [เชิงหลักการ — ไม่อยู่ในสไลด์] + formulary caveat.
- SHOULD: spleen = celiac-supplied, not foregut derivative; stems gained "not jaundiced", "nontender PR", "no CVA tenderness", "normal creatinine"; elderly MEQ stem now has RLQ phase, DDx retained, laparoscopy only when stable; neoplasm follow-up wording tied to abscess ≥35 y (WSES 2025); AAA card de-ambiguated; duodenal key reworded to avoid cueing.

## Known gaps — deliberately not tested
- Doses other than prophylaxis; stress-dose steroid; PPI for PPU (not in source).
- Interval appendectomy beyond WSES 2025 summary wording (full text not read).
- Open-appendectomy layers and lap steps carded only lightly (practice variation in technique).
- Pediatric DDx (intussusception, mesenteric adenitis) only as distractors.

## Overlap with other sets (same Subject)
Tiger sum GS2 Ch1/Ch2 and GenSx Ch09 cover the same diseases (abdominal exam/PR OSCE, consent OSCE, pregnancy, appendiceal mass, POD6 pelvic abscess, CODA %, Alvarado/AIR). This set took different angles; the appendiceal-mass OSCE and elderly MEQ Q5 (POD6 abscess) partly overlap. Filter by Topic to drill one lecture.

## Retiring this set
Filter `Topic LIKE 'Acute abdomen & Appendix%'` (created 2026-10-21 01:51:43Z–01:52:00Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

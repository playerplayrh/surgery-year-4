# Question bank — Surgical board review 2024 HNB (อ.จิรัฐ)

- **Database:** Recall Surgery (data source `b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
- **Source:** the deck "Surgical board review 2024 HNB" (Jirat Leelapatanadit, Phramongkutklao), turned first into two verified summary PDFs: Breast_Surgery_Summary.pdf (6 chapters) and Thyroid_Parathyroid_Surgery_Summary.pdf (5 chapters). The items were written only from those two summaries.
- **Date:** 2026-10-26

## Subjects and Topics

| Subject | Topic | Items |
|---|---|---|
| Breast | `Surgical board review 2024 HNB — Breast (อ.จิรัฐ)` | 44 |
| Head-Neck & Endocrine | `Surgical board review 2024 HNB — Thyroid & Parathyroid (อ.จิรัฐ)` | 65 |

## Counts

| Type | Breast | Thyroid/PTH | Total |
|---|---|---|---|
| MCQ | 20 | 30 | 50 |
| Flashcard | 20 | 28 | 48 |
| MEQ | 3 | 5 | 8 |
| OSCE | 1 | 2 | 3 |
| **Total** | 44 | 65 | **109** |

- **Difficulty:** 33 Easy, 54 Medium, 22 Hard.
- **MCQ key spread:** 10 each for A, B, C, D and E.
- **Status:** all 109 items are `Ready`.
- **OSCE stations:** consent for WLE + SLNB; thyroid/neck lump examination; post-thyroidectomy hematoma (SCOOP).

## Editorial rules for this set

- The lecturer's board cases were rewritten as full English vignettes with vitals.
- Two breast cases were **not** made into MCQs because the answer tick in the deck sits between two options: recurrence after BCS + ALND, and phyllodes with a 2.5-cm palpable node. The hidden-slide case on bloody discharge in pregnancy was also not used.
- **MEN2 timing:** the slide swaps MEN2A and MEN2B. The items test the ATA 2015 version (M918T in the first year of life; C634 by age 5), and the explanation names the slide version.
- **Hypercalciuria (PHPT):** both thresholds are named — the 2022 workshop figure (> 250 mg/24 h in women, > 300 mg/24 h in men) and the slide's 400 mg.
- **Pheochromocytoma screening:** the key is plasma free metanephrines; the slide's urine VMA is mentioned in the explanation.
- The slide case written "6-year-old woman" with a low TSH was rewritten as an adult (26 years).
- The 3-cm PTC cN0 case was not used as an MCQ, because lobectomy and total thyroidectomy are both defensible under ATA 2015/2025.
- No drug dose is tested. KI/Lugol and rhTSH appear only with the ⚠ verify note.

## What verification changed

An independent reviewer answered all 50 MCQs blind before seeing the keys; 50/50 agreed. It then web-checked the guideline claims. All 28 scripted edits were applied by search-and-replace.

**Blockers**
- **Microinvasion + HER2 3+:** the explanation had said "no systemic micrometastasis". Microinvasion is invasive cancer; the explanation now says the course treats it by DCIS rules and that NCCN lists systemic therapy only as "consider".
- **Pregnancy:** the explanation implied RT was allowed in the first trimester. RT is deferred until after delivery in every trimester.

**Fixes**
- **DCIS adjuvant MCQ:** a patient goal was added to the stem, because NCCN makes endocrine therapy optional and "WBRT alone" was otherwise also defensible.
- **LCIS:** the explanation now names both versions — the course excises all LCIS, while current guidance allows observation of concordant classic LCIS.
- **IBCSG 23-01 flashcard:** corrected to T ≤ 5 cm with any number of micrometastatic nodes. "1–2 nodes" is the Z0011 rule.
- **Complex cyst:** the flashcard's "4A" was inconsistent with a 23–31% cancer risk; corrected.
- **ATA high risk:** the cut-off is a node > 3 cm, not ≥ 3 cm.
- **Fine pleomorphic calcification:** BI-RADS 4B in ACR, 4C in the slide; both are named.
- **Cernea type 2b:** crosses below the upper border of the pole (not "within 1 cm").
- **Oncotype N1:** the cut-off is now RS 26.
- Stem/explanation mismatches were fixed in the FNA-not-done case, the hypocalcemia case and the 2-cm vs 3.1-cm node case.

**After review**
- The MTC MEQ vignette was changed so it no longer copies the MTC MCQ.
- The substernal-goiter MCQ now states the rectal cancer is early-stage and treated first.

## Known gaps / caveats

- **Not confirmed outside the slide (operative/anatomy claims):** subtotal remnant "6–8 g per side", and substernal approach chosen by lower-pole level.
- **Post-NST management of ypN0(i+)** follows the source (ALND); current practice is evolving.
- **Near-duplicates:** several MEQs reuse the scenario of an MCQ in the same set (discordant calcification/ADH, Bethesda IV → FTC, PTC with lateral node, Graves pre-op/hypocalcemia, hematoma). The Breast subject also already has an IBC MEQ from the Lecture 15 set.
- **The source does not teach:** breast reconstruction and peri-op orders; thyroid storm management; detailed calcium dosing.

## Notes

- **Post-upload SQL check was not run:** the Notion query allowance was exhausted. Every upload call returned all its pages created (66 + 43 = 109), with properties echoed back. A spot search confirmed items from several batches in the database.
- New rows appear in the recall app only after running `./publish.sh` in the `med-recall` folder.

# Question bank — Fluid & Electrolyte (Supparerk) (Recall Surgery)

Source: "Fluid and electrolytes" lecture, Supparerk Prichayudh MD (Dept. of Surgery, KCMH), 17 annotated slide pages + a student's summaries, plus the web-verified Ultimate Summary PDF built from it (fluid_electrolyte_acidbase_summary.pdf, Oct 2026).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-15 (rows created 07:10:38Z–07:11:04Z). Topic prefix: `Fluid-Electrolyte (Supparerk) · ChN …`. Subject = Perioperative care for every item. No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Body fluid & IV fluid therapy | 10 | 9 | 1 | 2 | 22 |
| Ch2 Electrolyte disorders | 9 | 9 | 1 | 1 | 20 |
| Ch3 Acid-base | 9 | 8 | 1 | 0 | 18 |
| **Total** | **28** | **26** | **3** | **3** | **60** |

OSCE stations: writing a post-op fluid order (Case 1, 50 kg post-appendectomy) · post-op hypotension/oliguria review · perioral numbness after total thyroidectomy (hypocalcemia).
MEQs: GOO two-bag order (MN 5% DNS/2 + KCl, loss NSS) · post-op hyperkalemia with AKI · GOO paradoxical aciduria interpretation + orders.
MCQ key spread: A 6 · B 6 · C 6 · D 6 · E 4. Stems 330–496 chars, all with vitals. Difficulty: Easy 19 · Medium 30 · Hard 11. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names in the DB (640 rows); all `Status = Ready`.

## Editorial rules applied
- MCQ fully English; lead-ins weighted to decisions: resuscitate vs calculate, which fluid for which loss, K in POD 0–1, first drug in hyperkalemia, hyponatremia by volume status, IV calcium in tetany, ABG interpretation that changes management. 7 Ch3 MCQs require calculation (Winter's, corrected AG, delta ratio, urine AG, osmolal gap, metabolic alkalosis and respiratory compensation); numbers chosen so every textbook formula variant gives the same answer.
- Slide/student corrections keyed to current guidance, with the slide answer named in the explanation: UKKA hyperkalaemia (Ca gluconate 10% 30 mL; resonium not routine); DKA 2024 consensus (insulin delayed if K < 3.5, bicarbonate only pH < 7.0); hypercalcemia loop diuretic not routine (Endocrine Society 2023); metabolic alkalosis formula 0.7×HCO₃⁻ + 20.
- Doses only from the verified sources, with the formulary note. Lecturer-only numbers (peripheral osmolarity < 650, Ca > 12.5 pancreatitis) not used as keys.

## What verification changed
Independent reviewer answered all 28 MCQs blind — 27/28 agreed with keys. 31 scripted fixes (1 must-fix, 11 should-fix, 5 nit):
- MUST-FIX: post-op hyponatremia MCQ had two defensible answers (acute 13 mmol/L fall + headache/nausea fits the European 3% bolus indication) → recast as asymptomatic, Na 138 → 131, so only water restriction fits.
- Saline-vs-LRS contradiction between two ileostomy items removed (one key changed to "IV isotonic crystalloid").
- "No K POD 1" item: K raised to 5.0 so NICE and the lecture rule agree.
- ABG added to the NSS-hyperchloremia stem; albumin added to the fistula NAGMA stem.
- NaHCO₃ in hyperkalemia softened to "not routine" (UKKA) in an MCQ and the MEQ; MEQ urine output 0.45 mL/kg/h flagged as borderline for starting K.
- Four near-duplicate scenarios re-set (different operation/context); one flashcard cut to one fact; the slide's inconsistent "70–90 mEq/d" Na removed from a card; NICE comparator added to the fluid-order OSCE.
- Not changed: the key is the longest option in 11/28 MCQs (all ≤ 1.5× median) — watch on the next set.

## Known gaps — deliberately not tested
- Colloid real-world volume ratio; TPN start timing beyond the slide's "> 7 days or malnutrition"; RELIEF/restrictive fluid; ERAS fasting/carb-loading times; pediatric maintenance (isotonic) — unverified in the summary.
- ODS onset timing; hypernatremia correction rate; 3% NaCl bolus volume; refeeding calorie/dose specifics; calcium chloride equivalence; hyponatremia correction liberalisation debate (practice split).
- Balanced vs saline for general resuscitation (SMART only as a flashcard fact).
- Urine Cl cut-off for chloride-responsive alkalosis and the "pH > 0.08 per 10 = acute" rule (principle-level only).

## Retiring this set
Filter `Topic LIKE 'Fluid-Electrolyte%'` (rows created 2026-10-15 07:10:38Z–07:11:04Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

---

# Question bank — Professionalism & Surgical Safety (L07) (Recall Surgery)

Source: lecture "Professionalism / Patient Safety / Good Surgical Practice" (L07, 56 slides with handwritten annotations), plus the web-verified Ultimate Summary PDF built from it (Professionalism_Surgical_Safety_Summary.pdf, 18 Oct 2026).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-18 (rows created 04:35:40Z–04:36:20Z). Topic prefix: `Professionalism & Surgical Safety · ChN …`. Subject = Perioperative care for every item (user's choice). No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Medical professionalism | 9 | 9 | 1 | 1 | 20 |
| Ch2 Patient safety in the OR | 10 | 10 | 1 | 1 | 22 |
| Ch3 Good surgical practice (RCST 2552) | 8 | 8 | 1 | 1 | 18 |
| **Total** | **27** | **27** | **3** | **3** | **60** |

OSCE stations: relative asks for a competent patient's diagnosis and a copy of the records (confidentiality, rights #6/#8; 7 min) · lead a WHO Time out before open right hemicolectomy (6 min) · student asks to perform PR (introduce, consent, chaperone; 7 min).
MEQs: competent man refuses colectomy while son offers to sign for him (autonomy, consent, confidentiality, justice) · obese woman, night emergency laparotomy for presumed appendicitis → ruptured ectopic, nurse change, gauze short at closure (RSI risk factors → count-discrepancy sequence → X-ray → documentation → system prevention) · resident's bile duct injury during lap chole with an unreachable supervisor (supervision, op note, disclosure, reporting, M&M).
MCQ key spread: A 5 · B 6 · C 5 · D 6 · E 5. Stems 351–455 chars. Difficulty: Easy 17 · Medium 30 · Hard 13. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names in the DB (1,821 rows); all `Status = Ready`.

## Editorial rules applied
- MCQ fully English; lead-ins weighted to decisions: stop at time out when anything conflicts, what to do when the count is off, which checklist phase owns which item, which commitment/principle/right is breached, supervisor and trainee duties.
- Only numbers in the summary/slides: JCAHO 76/13/11%, 126 RCA 41/20/14/11%, 58% ambulatory, 2023 closed claims 83.8%; Gawande RR 8.8 / 4.1 / 1.1, sponge 69% : instrument 31%; Haynes 1.5→0.8%, 11→7%; WHO 500 mL (7 mL/kg children), antibiotic within 60 min; rights 2558 (proxy ≤ 18 y); แพทยสภา 50/2563 (10 clauses, 29 Jun 2563).
- The unverified ASHP/IDSA 120-minute antibiotic window and "routine X-ray in every case" (practice variation) are not used anywhere.
- Lecturer-only views attributed: 50/2563 "advisory, no penalty in itself" (clause 10 refers to existing law); site mark shows side/position, not organ; neuro (flipped imaging) and uro (stone migration) as wrong-site reasons.
- RCST 2552 items rest on the slides only (original not found online).

## What verification changed
Independent reviewer answered all 27 MCQs blind — 27/27 agreed with keys; no must-fix. 12 scripted fixes plus one follow-up:
- RSI root-cause MCQ: "inadequate wound exploration" distractor was also defensible → reworded to "surgeon declining to explore".
- Ch3 supervision MCQ duplicated the Ch3 MEQ vignette (lap chole) → recast as open inguinal hernia repair.
- PR OSCE title no longer gives away the marking scheme; an unobservable checklist item (charting) replaced; an unobservable item removed from the confidentiality OSCE.
- 50/2563 MCQ: recorder changed from visitor to patient (the announcement is about patients' duties); distractor B reworded to fit.
- Quality-of-care flashcard: removed examples that were the summary's, not the lecturer's.
- Minor wording: one length-cued key shortened, one distractor rationale reworded to stay within the source, one tone fix.

## Known gaps — deliberately not tested
- Charter commitments to appropriate relationships, access to care and scientific knowledge appear only as distractors (source gives one-line definitions).
- Patient rights #1 and #7, 50/2563 clauses 1–7 in detail, JCAHO 1998 15-case review, the ~1/yr RSI incidence figure, Haynes antibiotic 56→83%.
- RCST: pediatric and transplant details beyond the donor-consent card, private practice, advertising/media, device warnings, logbook/evaluation (distractors only), infection-exposure rules.
- Informed-consent elements and open-disclosure steps (summary marks them as general principles, not slide content).
- Near-duplicates accepted (MEQ integrates the MCQ point): Gawande MCQ ↔ Ch2 MEQ Q1; count-short MCQ ↔ Ch2 MEQ Q2; nurse-handover RSI MCQ ↔ Ch2 MEQ; justice MCQ ↔ Ch1 MEQ Q4; student-introduction MCQ ↔ PR OSCE.

## Retiring this set
Filter `Topic LIKE 'Professionalism & Surgical Safety%'` (rows created 2026-10-18 04:35:40Z–04:36:20Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

---

# Question bank — Pre & Post-operative Care (Punthita) (Recall Surgery)

Source: "Preoperative & Postoperative Care" lecture, Punthita Aimsupanimitr MD (Dept. of General Surgery, KCMH), annotated slides plus an older bedside pre-op note (2562), via the web-verified Ultimate Summary PDF built from it (Pre_Post_Operative_Care_Summary.pdf, 18 Oct 2026). Items written from the summary's corrected text only.
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-18 (rows created 04:44:30Z–04:46:53Z). Topic prefix: `Pre-Post-op Care (Punthita) · ChN …`. Subject = Perioperative care for every item. No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Pre-operative evaluation & optimization | 11 | 10 | 1 | 1 | 23 |
| Ch2 Post-operative fever & care | 8 | 7 | 1 | 1 | 17 |
| **Total** | **19** | **17** | **2** | **2** | **40** |

User chose the ~40-item volume (high-yield only).
OSCE stations: write a pre-op order for a 62-year-old on ARB + thiazide + dapagliflozin before elective lap chole (8 min) · review a POD 5 febrile patient after open right hemicolectomy with Foley and central line (7 min).
MEQs: 70-year-old with rectal cancer, insulin + empagliflozin, DES 3 y ago on aspirin, 10% weight loss and albumin 28 → ASA, RCRI, tests (ECG + hs-troponin 0/24/48 h), drugs to hold/continue, ESPEN nutrition delay, Caprini 6 with extended LMWH · open sigmoid colectomy with fever evolving over week 1 → POD 1 approach (no reflex pan-culture, not "atelectasis") → POD 3–5 W work-up → POD 6 unstable leak → OR → pelvic abscess later.
MCQ key spread: A 4 · B 4 · C 4 · D 3 · E 4. Stems 380–497 chars, all with vitals. Difficulty: Easy 10 · Medium 21 · Hard 9. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names in the DB (1,916 rows); all `Status = Ready`.

## Editorial rules applied
- MCQ fully English; lead-ins weighted to decisions: proceed vs postpone vs test (stepwise cardiac evaluation, ≥4 METs), which pre-op test is indicated, antiplatelet/DOAC/SGLT2i hold days, stent timing, VTE prophylaxis tier, platelet/RBC thresholds, POD-based cause of fever, MH first step, unstable leak → OR.
- Guideline-keyed (verified): ESC 2022 (clopidogrel 5 / prasugrel 7 / ticagrelor 3–5 d; aspirin continued after PCI; elective surgery 6 mo after elective PCI, 12 mo after ACS; ECG + hs-troponin before and 24/48 h after for ≥65/risk factors + intermediate–high risk), PAUSE (DOAC 1 vs 2 d, no bridging), FDA SGLT2i (≥3 d, ertugliflozin 4), ASA fasting 2017/2023, ASHP/IDSA 2013 (≤60 min before incision, cefazolin redose q4h or >1,500 mL), AABB 2023 (Hb 7 / 7.5 cardiac / 8 ortho-CVD), AABB/ICTMG 2025 (plt <50k major non-neuraxial), ESPEN 2025, ASA PS 2020 examples.
- Slide/note corrections keyed to the current answer: NPO after midnight → clear liquids to 2 h; routine lab battery → selective; aspirin 7 d for all → continue with stents; Hct > 30 → restrictive Hb; hypotonic risk = hyponatremia, not hyperkalemia; early fever not keyed to atelectasis.
- Not used as keys or card facts (flagged unverified/principle-level in the summary): warfarin bridging, metformin day-of-surgery hold, stress-dose steroids, OCP stopping, ACCP 2012 Caprini cut-offs, neuraxial/neurosurgery platelet thresholds, dantrolene dose. ASA mortality % per class (old slide data) not used.

## What verification changed
Independent reviewer answered all 19 MCQs blind — 19/19 agreed with keys; no must-fix; all guideline facts confirmed. 26 scripted fixes:
- Post-MI MCQ explanation no longer calls a 6-week-old MI "recent" (ACC/AHA active condition ≈ 30 d); postponement kept, reason reworded.
- POD 1 fever MCQ: stem now states IV sites, calves and medications were checked (explanation said "every W negative"); a distractor copying the summary's own Q&A swapped for CXR + sputum culture.
- RCRI wording aligned between the flashcard and Ch1 MEQ (ESC Table 4 = 5 clinical factors; surgical risk scored separately).
- Pre-op order OSCE: hs-troponin at 24/48 h added; carbohydrate clear drink caveat for a diabetic (ASA 2023 recommendation is for healthy adults); Caprini 4 labelled "high risk per the slide table".
- Mallampati card now separates class I (pillars visible) from II; atelectasis card softened to "evidence does not support".
- Leak MCQ and PE MCQ re-set (operation/POD/vitals) to stop mirroring the summary's Q&A.
- Three length-cued keys shortened; an abbreviation-only key spelled out; stray formulary note removed from a no-dose item; BP added to the MH stem; DAPT card says "time-sensitive" surgery.
- Not changed: four Ch2 flashcards (MH, POD table, other causes, ESPEN feeding) still hold 2–3 linked facts within the length caps.

## Known gaps — deliberately not tested
- Post-op ileus vs early adhesive SBO — not taught in this lecture.
- Intra-operative care, ERAS components beyond feeding, specific analgesic regimens and doses — summary marks them principle-level.
- Warfarin/bridging, steroid cover, OCP, neuraxial platelet thresholds (unverified in the summary); ASA mortality table (old slide data).
- Overlap with Tiger sum GS1 (fasting, ESPEN delay, POD fever cards) and Fluid-Electrolyte (hyponatremia) accepted — different lecture and Topic.
- Within-set repeats by design: SGLT2i (MCQ ↔ Ch1 MEQ ↔ OSCE), troponin schedule (MCQ ↔ Ch1 MEQ), unstable leak (MCQ ↔ Ch2 MEQ ↔ OSCE), pelvic abscess (MCQ ↔ Ch2 MEQ).

## Retiring this set
Filter `Topic LIKE 'Pre-Post-op Care (Punthita)%'` (rows created 2026-10-18 04:44:30Z–04:46:53Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

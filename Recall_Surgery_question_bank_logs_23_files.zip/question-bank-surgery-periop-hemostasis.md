# Question bank — Hemostasis, Surgical Bleeding & Transfusion (Kritayakirana) (Recall Surgery)

Source: lecture "Hemostasis, surgical bleeding, and transfusion" (รศ.นพ.กฤตยา กฤตยากีรณ), 138 annotated slide pages incl. the student's own review note, plus the web-verified summary PDF built from it (Hemostasis_Surgical_Bleeding_Transfusion_Summary.pdf, 18 Oct 2026, 4 chapters).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-18 (after 04:22Z). Topic = `Hemostasis, Surgical Bleeding & Transfusion (Kritayakirana)` (single topic for the whole deck). Subject = Perioperative care for every item. No `Source` URL.

## Relation to existing sets
Added alongside — not replacing — `GenSx Vol.1 Ch03 Hemostasis, Surgical Bleeding, and Transfusion` (30) and `Tiger sum · GS1 Ch2 Peri-operative Antithrombotics & Concurrent Medications` (21). Writers got those 51 items as an exclusion list; the new set leans on this lecture's own content (the lecturer's in-class Q1–Q3, handwritten annotations, pre-op Level I–IV, local hemostasis, Hct-fall timeline, OR EBL guide, AHTR mechanism).

## Counts (verified by SQL after upload)

| Summary chapter | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Biology & bleeding disorders + Ch2 Antithrombotics & peri-op | 13 | 13 | 2 | 1 | 29 |
| Ch3 Surgical bleeding & damage control + Ch4 Shock & transfusion | 13 | 13 | 2 | 2 | 30 |
| **Total** | **26** | **26** | **4** | **3** | **59** |

MCQ key spread: A 6 · B 6 · C 6 · D 4 · E 4. Difficulty: Easy 14 · Medium 31 · Hard 14. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; all non-MCQ have Answer; 0 duplicate Names within the topic; all `Status = Ready`.
OSCE stations: pre-op warfarin review/counselling (AF, no bridging) · pre-op bleeding history before thyroidectomy (Level I–IV) · ordering and safely giving 1 unit PRC on the ward.
MEQs: post-LAR septic DIC · mechanical mitral valve on warfarin with hematuria (TURBT) · elective right hepatectomy developing the lethal triad (damage control) · elective Whipple transfusion arc (autologous donation, components, massive transfusion, TACO vs TRALI).

## Editorial rules applied
- Lecturer Q1 (healthy 60M, aspirin, inguinal hernia → lecture: stop 7 days) is a practice-variation point vs CHEST 2022 (continue for most) → flashcard framed as "lecture answer" only, never a single-key MCQ.
- Lecturer Q3 (Plt 50,000 before emergency laparotomy) has no written answer on the slide → only the unit-calculation rule is carded.
- Hemorrhage classes not tested again (table differs by ATLS edition; an item already exists).
- Lecture-vs-guideline numbers (O-neg ≤ 4 units vs MTP, massive transfusion definitions, cryo fibrinogen 100 vs 150) either avoided or both named; stems chosen so the key doesn't flip.

## What verification changed
Independent reviewer answered all 26 MCQs blind — 26/26 agreed. 0 must-fix, 8 should-fix, 13 minor. Applied by scripted replacement:
- DES 7 weeks after ACS: key reworded to "defer surgery and continue both antiplatelet agents"; explanation names CHEST 2022 (3 months) and AHA/ACC 2024 (~6 months CCD / ~12 months ACS).
- Primary fibrinolysis MCQ: "D-dimer only slightly raised" added to the stem so it can't be argued as DIC.
- vWD flashcard: vWF-containing factor VIII concentrate preferred over cryo when available.
- Septic DIC MEQ: antibiotics, CT for leak, re-laparotomy added to source control.
- Mechanical-valve MEQ: bridging + restart merged into one sub-question (they duplicated existing items).
- Whipple MEQ: cardiology check before autologous donation in IHD; sub-question 3 re-set to platelets < 50k + fibrinogen < 100 (was a copy of an MCQ); hypocalcemia cue removed from sub-question 4.
- Minor: Bernard-Soulier DDAVP softened; HIT onset 5–10 days (ASH) vs lecture 5–7; NICE NG45 note on routine coag tests; PRC 42 days "with additive solution"; Stone attribution kept to "the slide cites"; irrelevant dextran line removed from the PRC OSCE.
- Accepted: damage-control MCQ kept (the existing trauma MEQ doesn't test abbreviated laparotomy vs definitive repair); prostate-EACA tested twice (post-op disease vs intra-op organ); Level I–IV scheme appears in 4 items.

## Known gaps — deliberately not tested
- Exact factor-replacement targets, DDAVP dose, 4F-PCC IU/kg table, FFP mL/kg (summary leaves these to protocol).
- ATLS 11th-edition class table (unverified whether the numbers changed).
- Viscoelastic testing (TEG/ROTEM) thresholds; post-transfusion purpura (not in this lecture).
- Thai MTP protocol specifics (already in the GenSx Ch03 MEQ).

## Retiring this set
Filter `Topic = 'Hemostasis, Surgical Bleeding & Transfusion (Kritayakirana)'`. MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

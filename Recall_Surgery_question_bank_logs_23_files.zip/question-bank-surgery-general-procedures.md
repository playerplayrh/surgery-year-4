# Question bank — 03 Procedure Review (Recall Surgery)


Source: "Procedure Review" lecture (minor surgical procedures, Kahoot-based), 17 pages of photographed slides with handwritten annotations, plus the web-verified summary PDF built from it (Procedure_Review_Summary.pdf, Oct 2026).
Target: Notion `Recall Surgery`. Uploaded 2026-10-21 (rows created 01:40:54Z–01:41:41Z). Topic = `03 Procedure Review`; Subject = General surgery for every item. No `Source` URL.

## Counts (verified by SQL after upload)

| Type | n |
|---|---|
| MCQ | 18 |
| Flashcard | 21 |
| MEQ | 4 (one per chapter: wound dressing · local anesthesia/LAST · suturing · infected epidermoid cyst I&D) |
| OSCE | 3 (dry dressing 7 min · field block + I&D 10 min · simple interrupted suture 8 min) |
| **Total** | **46** |

MCQ key spread: A 3 · B 4 · C 4 · D 4 · E 3. Integrity: all MCQs have 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names; all `Status = Ready`.

## Editorial rules applied
- Kahoot answers all carried: Q4 lidocaine, Q6 infected inclusion cyst vs lipoma, Q7 paronychia, Q8 seroma. Q5 (needle holder) was not circled in the notes and was not made into an item.
- Doses used: lidocaine label limits only (plain 4.5 mg/kg ≤300 mg; with epinephrine 7 mg/kg ≤500 mg; 1% = 10 mg/mL), with formulary warnings. No lipid emulsion or ACLS epinephrine numbers.
- Guideline used: IDSA 2014 SSTI (I&D for abscess/carbuncle/inflamed epidermoid cyst; Gram stain + culture for abscess/carbuncle, not inflamed epidermoid cyst; antibiotics vs S. aureus with SIRS).
- Practice variation kept out of MCQ keys: adrenaline in digital block (stated as department teaching in flashcard/MEQ only; the MCQ specifies plain lidocaine), packing small abscesses, nail elevation technique (key relies on "spread widely").

## What verification changed
Independent reviewer answered all 18 MCQs blind — 18/18 agreed with keys. 3 must-fix, 7 should-fix, 5 minor; applied by scripted replacement:
- MUST: carbuncle stem RR 24 → 26 (IDSA tachypnea is >24); abscess-anesthesia distractor "intradermal over the dome" replaced (defensible technique) by "deep into underlying muscle"; LAST flashcard no longer says HT/tachycardia "is not LAST" — now "adrenaline effect, possible intravascular injection → stop and watch for LAST".
- LAST MCQ: patient weight added (50 kg → 5 mg/kg over limit), note that toxicity can occur below max dose; "secure" → "maintain" airway; ASRA lipid-early/avoid-propofol note.
- Ring-block wording softened in MCQ and flashcard (limited volume, not "ring block banned"); pseudoaneurysm stem given a risk factor (groin injection); nail-elevation explanation flags institutional variation; tape blisters moved to tape ends.
- Near-duplicates resolved: wound-dressing MEQ moved to a post-debridement shin wound (was same as the dressing MCQ); epidermoid MEQ given new demographics and the IDSA "no culture needed" note.

## Known gaps — deliberately not tested
- Lipid emulsion dosing, modified ACLS doses, bupivacaine max dose.
- Suture removal timing beyond one MEQ sub-answer; knot-throw counts.
- Paronychia antibiotics, chronic paronychia, matricectomy agents; seroma sclerotherapy.
- Forehand/backhand technique (note was hard to read); Ω taping beyond "no tension".

## Retiring this set
Filter `Topic = '03 Procedure Review'` (rows created 2026-10-21 01:40:54Z–01:41:41Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

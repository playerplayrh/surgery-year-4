# Question bank — Surgical Infection (Samorn) (Recall Surgery)

Source: "Surgical infection: Surgical consideration in Infectious diseases" lecture, Pasurachate Samorn MD (Dept. of Surgery, KCMH), with a classmate's annotated copy, the Micro department's SSTI slides (TSS/SSSS/NSTI), a student summary — plus the web-verified Ultimate Summary built from them (Surgical_Infection_Summary.pdf, 18 Oct 2026). Items were written from the summary text only.
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-18, rows created 04:38:15Z–04:38:35Z. No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | Subject | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|---|
| Surgical Infection (Samorn) · Ch1 Principles, sepsis & source control | Acute care & Critical care | 13 | 13 | 1 | 1 | 28 |
| Surgical Infection (Samorn) · Ch2 Surgical site infection | Perioperative care | 12 | 12 | 1 | 2 | 27 |
| **Total** | | **25** | **25** | **2** | **3** | **55** |

OSCE stations: initial assessment and management of sepsis from an intra-abdominal source (8 min) · demonstrate surgical hand scrub + skin preparation (7 min) · POD5 red, discharging wound review (8 min).
MEQs: diabetic with leg NSTI → resuscitation → LRINEC/imaging must not delay OR → debridement + empiric antibiotics (names only) → second look/amputation · diabetic smoker before elective sigmoid colectomy → optimization → prophylaxis plan → POD6 superficial SSI (IDSA criteria) → organ/space work-up.
MCQ key spread: A 5 · B 5 · C 5 · D 5 · E 5. Difficulty Easy 14 · Medium 31 · Hard 10. Integrity (SQL): every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; all `Status = Ready`; 0 duplicate Names in the whole DB.

## Editorial rules applied
- MCQ fully English, stems 369–520 chars with vitals; lead-ins weighted to decisions (PCD vs laparotomy, operate vs antibiotics, ERCP drainage, I&D, OR for NSTI regardless of score, prophylaxis timing/redosing/stop, when to add antibiotics to an opened SSI, skin-prep agent choice).
- No drug doses anywhere (drug names only). Thresholds only from the verified summary: Sepsis-3 (ΔSOFA ≥2; MAP ≥65 + lactate >2), SSC 2021 (1 h / 3 h antibiotics, norepinephrine first, against qSOFA as single screen), LRINEC ≥6 / ≥8, STOP-IT ~4 d, IDSA 2014 SSI antibiotic criteria (erythema >5 cm, T >38.5, HR >110, WBC >12,000), CDC 2017 (glucose <200, alcohol-based prep, no doses after closure even with drain), ASHP 2013 (60/120 min, redose cefazolin ~4 h / cefoxitin ~2 h or blood loss >1500 mL, no routine prophylaxis in low-risk lap chole), NHSN SSI windows.
- Slide vs guideline: vascular graft prophylaxis keyed to cefazolin (ASHP), slide's cloxacillin named in the explanation; appendectomy regimen card shows slide (ceftriaxone + metronidazole / cefoxitin) and ASHP side by side.

## What verification changed
Independent reviewer answered all 25 MCQs blind — 25/25 agreed with keys. 17 scripted fixes:
- MUST-FIX: the slide's SSI rates by wound class (2.1/3.3/6.4/7.1%) come from NNIS (Culver 1991, Am J Med), not ACS-NSQIP/Ortega 2012 — fixed in the flashcard and in the summary PDF.
- Serosanguinous-discharge flashcard reworded to "fascial (wound) dehiscence ± deep incisional SSI" (compression had made it wrong).
- Infected epidermoid cyst MCQ: en bloc excision distractor (practice variation, defensible) replaced.
- Lap-chole drain MCQ: removed "age" as a risk factor at 67 (ASHP high-risk age is >70).
- Perforated diverticulitis stem no longer scans a patient on norepinephrine (erect CXR + bedside US instead).
- 7 keys lengthened that were the shortest option (cueing); biliary-regimen explanation credits ceftriaxone + metronidazole to the slide.

## Known gaps — deliberately not tested
- Exact delayed-primary-closure day (slide 5–6 vs literature 3–5) and whether DPC reduces SSI (evidence split, incl. Thai meta-analysis 2014).
- NHSN 90-day procedure list; "5W" POD fever timeline days; second-look timing in NSTI; hernia-mesh prophylaxis; coding of non-perforated appendicitis (II vs III).
- SSSS and scarlet fever (Micro content, pediatric) — skipped; pyomyositis only as a flashcard.
- Antibiotic doses, durations beyond STOP-IT, MRSA risk stratification.
- Near-duplicate pairs to watch: NSTI MCQ (LRINEC 4 + crepitus) ↔ Ch1 MEQ; single diverticular abscess → PCD MCQ ↔ Ch2 organ/space PCD MCQ. Overlap with Tiger sum GS1 (peri-op) and Fluid sets is allowed.

## Retiring this set
Filter `Topic LIKE 'Surgical Infection (Samorn)%'` (rows created 2026-10-18 04:38:15Z–04:38:35Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

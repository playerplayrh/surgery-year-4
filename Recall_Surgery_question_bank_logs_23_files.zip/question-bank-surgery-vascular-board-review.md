# Question bank — Vascular (Surgical Board Review 2024, อ.กฤษดา หลวงรุ่งเรือง)

Run: 2026-10-29 · Target: Notion **Recall Surgery** · Subject `Vascular` · Status `Ready` (no Draft items)
Source: Surgical board review 2024 — Vascular Part I + Part II slides (รพ.พระมงกุฎเกล้า) + the Clinical Card PDF summary built from them (Vascular_Surgery_Board_Review_Summary.pdf). No `Source` URL (no Notion page for the source).

## Counts (114 items, verified by SQL in Notion — 0 duplicate Names, all per-type fields intact)

| Topic (`Surgical board review 2024 Vascular (อ.กฤษดา) · …`) | MCQ | Flashcard | MEQ | OSCE |
|---|---|---|---|---|
| Ch1 Acute limb ischemia & Compartment syndrome | 8 | 8 | 1 | 1 (cold-leg vascular exam + Doppler/Rutherford) |
| Ch2 PAD, CLTI & non-atherosclerotic limb ischemia | 8 | 8 | 1 | 1 (measure & interpret ABI) |
| Ch3 Carotid stenosis | 5 | 4 | 1 | – |
| Ch4 AAA & ruptured AAA | 7 | 7 | 1 | – |
| Ch5 Aortic dissection | 4 | 3 | 1 | – |
| Ch6 Mesenteric ischemia & SMA syndrome | 5 | 5 | 1 | – |
| Ch7 VTE — DVT, SVT, PE & prophylaxis | 8 | 9 | 1 | 1 (post-op swollen leg) |
| Ch8 Chronic venous disease | 3 | 3 | 1 | – |
| Ch9 Hemodialysis access | 3 | 3 | 1 | 1 (pre-op assessment for AVF) |
| **Total** | **51** | **50** | **9** | **4** |

MCQ key spread: A 11 · B 10 · C 10 · D 10 · E 10.

## Editorial rules applied
- MCQ fully English, 200–550-char vignettes with vitals; 5 unlettered options; explanation covers every distractor.
- Not tested (flagged ⚠/unverified in source or practice variation): intra-op rtPA 10 mg; bariatric enoxaparin 40/60 mg by BMI; compartment MAP−ICP threshold; pythiosis treatment; exercise-therapy schedule; ABI normal-range edges; WIfI ischemia grade-3 ankle pressure cell (slide typo "<70" — WIfI original <50); women's AAA surveillance intervals; aortomesenteric angle cut-off; claudication-prevalence percentages (slide vs summary disagree).
- Dissection anti-impulse targets: items name both slide (HR <60, SBP 100–120) and ACC/AHA 2022 (HR 60–80, SBP <120); no number is the discriminator.
- Doses carry "⚠ ตรวจสอบกับ formulary ของสถาบันก่อนสั่ง" (Thai) / "(verify dosing against your institution's formulary)" (English).

## What adversarial verification changed (2 reviewers, 0 critical / 3 major / 27 minor; 24 fixes applied)
- Ch1 MCQ (Rutherford IIa → CDT): removed "rest pain" from stem (cued IIb).
- Ch1 OSCE: I vs IIa separated by arterial Doppler (+ sensory), not sensory alone.
- Ch9 flashcard: dialysis catheter order now shows slide order (IJ > subclavian > femoral) and KDIGO 2012 (right IJ > femoral > left IJ > subclavian).
- Labelled as "per slide/lecture" where guidelines differ: NOMI = highest mortality (Schoots 2004: thrombosis 77% vs NOMI 73%); routine fibrinogen monitoring during CDT (ESVS 2020 advises against routine); stroke within 6 months as thrombolysis contraindication; TP <50 mmHg (GVG CLTI uses <30); LMWH CrCl <25.
- AAA CT signs regrouped (focal wall discontinuity = impending/complete; draped aorta = contained rupture); ESVS 2024 thresholds noted as downgraded to "should/may be considered".
- Added ESVS 2017 note that endovascular stenting is first-line for acute SMA thrombosis where available; open repair for TEVAR failure or unsuitable anatomy; AR murmur location; DOACs for cancer-associated VTE in MEQ; pathologic perforator criteria in CVD MEQ; one Ch7 flashcard split into two (1st unprovoked vs 2nd unprovoked/cancer duration).

## Known gaps (source didn't teach — not imported)
- Upper-limb ischemia beyond brachial embolectomy, thoracic outlet, renal artery disease, vascular trauma (covered elsewhere: GenSx Ch21), lymphedema, vascular malformations, peri-op antibiotic prophylaxis for vascular surgery.

## Overlap with existing vascular sets
Tiger sum GS5 Ch1–3 and GenSx Vol.1 Ch16–18/21 already cover ALI, PAD/CLTI, CVD, VTE and vascular injury; this set differs by following this lecturer's slides (ESVS 2020/2023/2024 algorithms, WIfI, ESVS carotid algorithm, HD access, mesenteric ischemia, SMA syndrome).

# Question bank — Tiger sum (General Surgery Ultimate Summary, GS1–GS8) (Recall Surgery)

Source: the 8 Ultimate Summary PDFs built 2026-10-16 from Waritnun's Google Doc "🪡 General Surgery" (GS1_Periop_Care … GS8_Oncology_Transplant, 491 pages, web-verified; the PDFs already correct the original notes). Items were written from the PDF text only — the corrected version, never the "note wrote X" version.
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-16, rows created 11:13:18Z–11:21:35Z. No `Source` URL.
Topic format: `Tiger sum · GSn ChN <chapter title>` (40 chapters). Subject per chapter.

## Counts (verified by SQL after upload)

| PDF | Subject | Chapters | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|---|---|
| GS1 Peri-op care | Perioperative care | 6 | 60 | 60 | 6 | 2 | 128 |
| GS2 Acute abdomen, appendix, small bowel | General surgery | 5 | 50 | 50 | 5 | 2 | 107 |
| GS3 Upper GI | Upper GI | 7 | 70 | 70 | 7 | 2 | 149 |
| GS4 Hernia | General surgery | 4 | 40 | 40 | 4 | 1 | 85 |
| GS5 Vascular | Vascular | 3 | 30 | 30 | 3 | 2 | 65 |
| GS6 Thyroid/PTH + Breast | Head-Neck & Endocrine (Ch1–3) · Breast (Ch4–6) | 6 | 60 | 60 | 6 | 2 | 128 |
| GS7 HPB | Hepatobiliary & Pancreas (HPB) | 6 | 60 | 60 | 6 | 2 | 128 |
| GS8 Oncology + Transplant | Surgical oncology (Ch1) · Transplant (Ch2–3) | 3 | 30 | 30 | 3 | 1 | 64 |
| **Total** | | **40** | **400** | **400** | **40** | **14** | **854** |

Per chapter: 10 MCQ + 10 Flashcard + 1 MEQ (user asked for 20 MCQ+FC per chapter; MEQ/OSCE "as appropriate").
OSCE stations: GS1 post-op order (R hemicolectomy) · GS1 POD2 fever + low UO review · GS2 acute-abdomen exam incl. PR · GS2 consent lap appendectomy · GS3 caustic initial assessment · GS3 breaking news esophageal SCC (SPIKES) · GS4 groin hernia exam · GS5 acute limb assessment + Doppler/Rutherford · GS5 ABI technique · GS6 neck lump exam · GS6 breast exam · GS7 POD1 post-LC review · GS7 post-splenectomy counselling · GS8 consent lap sigmoid colectomy for cancer.
MCQ keys: 80 per letter A–E. Difficulty: Easy 212 · Medium 489 · Hard 153. All `Status = Ready`, none Draft.
Integrity (SQL): every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; Flashcard/MEQ/OSCE all have Answer; 0 duplicate Names in the whole DB (1,612 rows); per-topic text-length checksums identical to the local files.

## Editorial rules applied
- MCQ fully English, vignettes with vitals (stems ~225–550 chars); lead-ins weighted to surgical decisions. Flashcards ≤3 lines / ≤350 chars, Thai structure + English terms. MEQ Thai, 4–5 sub-questions on the surgical arc. OSCE 12–16 checklist items.
- Nothing the PDFs flag "⚠ ยังไม่ได้ verify" or practice variation is used as an MCQ key or flashcard fact (e.g. 3-cm PCD cut-off, "6 h flatus", 6-h strangulation, sedation doses, %FLR/ICG cut-offs, WIfI/GLASS matrices, Ki-67 cut-off, AJCC stage groupings where unverified, achalasia PD-vs-POEM equivalence, Thai allocation scoring).
- Split-evidence topics written so only one option fits (antibiotics-first appendicitis, cholecystectomy timing, gallstone-ileus one- vs two-stage, breast abscess aspiration vs I&D, mesh in contaminated field).
- Doses avoided; where present they carry the formulary warning.
- Overlap with older sets (UGI-MIS, Gallstone-MIS, Liver, Hernia, Fluid) allowed by the user.

## What verification changed
Independent reviewer per PDF answered all 400 MCQs blind: 397/400 agreed; the 3 disagreements resolved without moving any key. 78 scripted fixes (4 must · 51 should · 23 nit), 0 items dropped:
- GS8 apnea test: stem now specifies Thai Medical Council criteria (PaCO2 ≥60 OR rise ≥20); explanation adds that the 2023 US consensus requires both (+ pH <7.30). Same note added to the brain-death MEQ.
- GS7 Revised Atlanta flashcard: moderately severe = transient OF and/or local/systemic complication (had read as OF required).
- GS7: adenoma MCQ made asymptomatic (symptoms made resection defensible); neoadjuvant distractor swapped out of a resectable-Whipple item; 5 MCQs and 3 MEQs that copied the PDF's own Q&A numbers re-numbered.
- GS2: ileocecal-valve closed-loop mechanism corrected; AMI MEQ sends hypotensive peritonitis straight to OR; 10 length-cued keys shortened.
- GS1: NICE adult maintenance named in lead-in (Holliday–Segar also defensible otherwise); weight loss 13%→16% to clear the ESPEN threshold; unverified "2–5 days" removed from delayed-primary-closure card.
- GS4: three stems gained the findings their explanations used (no prior surgery, no bowel resection, no dysuria).
- GS6: PMRT ≥4 nodes citation corrected (2016 update covered 1–3 nodes) — the GS6 PDF carries the same small citation slip.
- Upload: one uploader dropped a word from a GS6 stem and added a stray character to a GS1 MEQ — both found by checksum and restored; one GS3 caustic flashcard renamed ("Caustic: …") because its Name duplicated a UGI-MIS card.

## Known gaps — deliberately not tested
- Everything the PDFs list as unverified (see each PDF's ⚠ items): drug doses generally, RCRI cut-offs, LMWH anti-Xa, lymph-node yield numbers, adjuvant imatinib duration (GS8), MELD exception points, Milan/King's in GS8, NCCN resectability version, platelet thresholds after splenectomy, CEAP vein-size cut-offs, alteplase/aPTT targets.
- No trauma, burn, colorectal, urology, neurosurgery or CVT items — the source doc doesn't cover them.
- Within-set cross-type repeats exist by design (same fact as MCQ + MEQ step); no same-type near-duplicates.

## Retiring this set
Filter `Topic LIKE 'Tiger sum%'` (rows created 2026-10-16 11:13:18Z–11:21:35Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

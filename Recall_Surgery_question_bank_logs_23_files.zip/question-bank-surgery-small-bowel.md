# Question bank — Small intestine & SBO (Lecture 12)

- **Built:** 2026-10-21 · target: Notion **Recall Surgery** (data source `b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
- **Source:** `12_Small_intestine_for_4th_yr_med_student` (115 slides incl. handwritten lecture notes + an abdominal-film lecture) and the summary PDF `Small_Intestine_SBO_Summary.pdf` built from it
- **Topic string (all items):** `Small intestine & Small bowel obstruction (Lecture 12)`
- **Source URL:** none (no Notion page for the source) — omitted

## Counts (verified in Notion by SQL)

| Subject | MCQ | Flashcard | MEQ | OSCE | Total |
|---|---|---|---|---|---|
| General surgery (anatomy, SBO, ileus) | 18 | 16 | 1 | 2 | 37 |
| Vascular (acute mesenteric ischemia) | 9 | 8 | 1 | 0 | 18 |
| Radiology (acute abdomen series) | 8 | 9 | 1 | 1 | 19 |
| **Total** | **35** | **33** | **3** | **3** | **74** |

- All Status = Ready; no Draft items
- MCQ key spread: A 8 · B 8 · C 7 · D 6 · E 6
- Integrity: every MCQ has 5 choices + Correct + Explanation; every OSCE has Checklist + Minutes; 0 duplicate Names

## Editorial rules applied
- MCQ in English, full vignettes with vitals (stems 400–530 chars); lead-ins weighted to next-best-step / operate vs NOM / timing / POD complications
- Flashcards Thai-structured, ≤3 lines / ≤350 chars; MEQ uses real newlines
- No drug doses anywhere; numbers only from the source (75% adhesion, 70% partial resolve, 6–12 h flatus, >3 cm, 70–80% sensitivity, 72 h NOM, 24 h contrast film, SB 24 h / stomach 48 h / colon 3–5 d, 3 h / 6 h ischemia, MVT 5–15%, SMV ~95%, 3-6-9)
- Practice variation not keyed as single answers: complete obstruction / virgin abdomen = operate, plain film vs CT first, cholecystectomy timing in gallstone ileus, porcelain GB management

## What verification changed
- Adversarial review worked all 35 MCQs blind: **0 wrong keys**
- AMI + peritonitis MCQ: option "CTA before surgery" reworded to "Defer surgery until CTA…" (was defensible under WSES 2022 Rec 5); explanation now cites Rec 9
- SBO MEQ (POD 5): sub-question 5 now sends POD-5 post-anastomosis ileus straight to CT (was contradicting the ">3–5 days → CT" rule and another MCQ); added antibiotic step for strangulation; "PR 120/min" → "HR 120/min"
- NG-tube OSCE: placement confirmation now "aspirate + pH per hospital protocol, not auscultation" (NG technique is standard practice, not taught in the source)
- Minor: reperfusion MCQ explanation (stable Hb doesn't exclude early bleeding), NOMI option "reduce or switch vasopressor", SBO MEQ vignette no longer gives away sub-question 3, one key shortened so it isn't the longest option, flashcard formatting
- **Source error found:** slide 66 lists fat as lighter than fluid. Correct order air < fat < fluid/soft tissue < bone < metal. The density flashcard teaches the correct order with a ⚠ note; the summary PDF was corrected too.
- Summary PDF citation fixed: peritonitis → laparotomy is WSES 2022 Rec 9 (not Rec 4–5)

## Known gaps (not taught in the source — not imported)
- Other small bowel diseases are only listed by name in the slides: Crohn's, ECF, radiation enteritis, neoplasm, acquired diverticulum, short bowel syndrome have no dedicated items (Meckel's has one MCQ from the summary's supplement)
- Chronic mesenteric ischemia, perforated peptic ulcer surgery, NG insertion technique (OSCE uses standard steps)
- Near-duplicate clusters to watch when drilling: gallstone ileus (2 MCQ + 1 FC), POD-2 ileus (2 MCQ), CTA in AMI (2 MCQ + MEQ), the two SBO-strangulation MEQ scenarios (SBO MEQ and Radiology MEQ share a theme)

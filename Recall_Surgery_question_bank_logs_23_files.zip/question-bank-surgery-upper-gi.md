# Question bank — UGI-MIS อ.ธราธร 2024 (Recall Surgery)

Source: "Minimally Invasive Surgery and Upper GI Surgery for Surgical Resident 2024", อ.ธราธร สุวัฒนารักษ์ (Siriraj), 215 slides — a **board review lecture** — plus the verified Ultimate Summary built from it (Oct 2026).
Target: Notion data source `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-10. No `Source` URL (the slides have no Notion page).
Topic prefix: `Board review UGI-MIS (อ.ธราธร 2024) · ChN …` (relabelled 2026-10-15 from `UGI-MIS อ.ธราธร 2024 · ChN …` so the recall site shows these as board-review lecture questions; all 182 rows, verified by SQL).

## Counts (verified by SQL after upload)

| Type | n |
|---|---|
| MCQ | 88 |
| Flashcard | 76 |
| MEQ | 15 |
| OSCE | 3 |
| **Total** | **182** |

| Chapter (Topic) | Subject | n |
|---|---|---|
| Ch1 MIS physiology & UGI anatomy | Upper GI | 10 |
| Ch2 Esophageal perforation | Upper GI | 12 |
| Ch3 Caustic ingestion | Upper GI | 12 |
| Ch4 Achalasia, motility & diverticula | Upper GI | 12 |
| Ch5 Hiatal hernia, volvulus & GERD surgery | Upper GI | 12 |
| Ch6 H. pylori & peptic ulcer disease | Upper GI | 16 (2 MEQ: PPU, GOO) |
| Ch7 Upper GI hemorrhage | Upper GI | 15 (incl. OSCE) |
| Ch8 Gastrectomy reconstruction & postgastrectomy syndromes | Upper GI | 12 |
| Ch9 Esophageal cancer | Upper GI | 13 (incl. OSCE) |
| Ch10 Gastric & EGJ cancer | Upper GI | 13 |
| Ch11 Gastric SET, GIST & lymphoma | Upper GI | 11 |
| Ch12 Colonic polyp & ERCP | Colorectal & Anal 6 / HPB 5 | 11 |
| Ch13 Abdominal wall hernia | General surgery | 12 (incl. OSCE) |
| Ch14 Adrenal surgery | Head-Neck & Endocrine | 12 |
| Ch15 Bariatric & metabolic surgery | Upper GI | 9 |

OSCE stations: initial management of UGIB (8 min) · POD5 post-esophagectomy tachycardia/AF + fever (8 min) · focused groin-lump examination (7 min).
MCQ key spread: A 18 · B 20 · C 18 · D 17 · E 15. Integrity: all MCQs have 5 choices + Correct + Explanation; all OSCE have Checklist + Minutes; 0 duplicate Names. All items `Status = Ready`, none Draft.

## Editorial rules applied
- MCQ fully English, USMLE/NL vignettes 200–550 chars with vitals; lead-ins weighted to surgical decisions.
- Flashcards ≤3 lines / ≤350 chars, one fact each, Thai structure + English terms.
- Every number traced to slides or the web-verified fact sheet; doses carry a formulary-verify note.
- Where the slide is outdated, items are keyed to the current guideline and the explanation names the slide/Thai answer:
  - GBS ≤1 = outpatient (ESGE/ACG); "GBS ≥8 → ICU" presented only as a local rule.
  - Rebleed after 2nd endoscopy → TAE before surgery (ESGE 2021); slide answer (surgery) noted.
  - NSBB target resting HR 55–60 (not 20–25% reduction); octreotide 2–5 d (Baveno VII).
  - Dumping: modified OGTT 75 g (2020 consensus), scintigraphy not diagnostic.
  - Adjuvant nivolumab for non-pCR after nCRT (CheckMate 577); imatinib 400 mg × 3 y adjuvant, 800 mg only advanced exon 9.
  - Primary aldosteronism keyed to Endocrine Society 2025; HDGC affects both sexes; ALDH2 = aldehyde dehydrogenase.
  - Caustic: CT decides surgery in adults (WSES 2019); steroids not recommended.

## What verification changed
Independent reviewer answered all 88 MCQs blind — 100% agreement with keys. 37 scripted fixes across 31 items (1 must-fix, 19 should-fix, 17 nit), plus one flashcard reshaped to fit caps:
- Impossible EGJ tumour geometry in one Siewert/Nishi MCQ corrected (key unchanged).
- Wrong post-adrenalectomy potassium physiology corrected.
- Stapfer type contradiction resolved (retroperitoneal air alone = type IV).
- Unstable patients no longer sent to CT/endoscopy in 4 items.
- Unverifiable citations removed (Baveno carvedilol claim, SB balloon "6 h", JES nivolumab wording, CXR free-air %).
- Crow's foot wording (denervated, not divided) fixed; metanephrine "screening = confirmation" softened; JNET 2B reclassified; AVS card aligned with ES 2025.
- 6 MCQs with length-cued keys shortened.

## Known gaps — deliberately not tested (slides don't settle them / practice variation)
- Bougie size, mesh threshold for hiatal repair, Dor vs Toupet choice, pyloric drainage & conduit route choice, drains/diet timing.
- PPU non-operative vs surgery in stable contained perforation; definitive acid-reducing surgery; Forrest IIb clot handling.
- Slide-only numbers not verified: Forrest rebleed %, HSV/TV table, Pittsburgh cut-offs, SB-tube traction weight, CRS/HIPEC PCI, EGJ margin 2.8/2.0 cm, supplement doses (slide 123), Roizen PVC criterion, MIBG size, ABCD ≥8, ACTH cut-offs, EUS size cut-offs, washout CT values, polypectomy size cut-offs, PEP drug doses.
- Post-op ileus vs early adhesive SBO vs leak by POD — not taught in this lecture; no item.
- Generic peri-op (antibiotic/VTE prophylaxis, ERAS) not tested — the slides don't teach it.
- Near-duplicate cluster to watch: adrenal MCQs on incidentaloma work-up overlap MEQ sub-questions.

## Retiring this set
Rows were created after `2026-10-10 09:46:43Z`; filter `Topic LIKE 'Board review UGI-MIS%'`. MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

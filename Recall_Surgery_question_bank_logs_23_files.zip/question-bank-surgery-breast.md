# Question bank — Breast (Lecture 15, อ.มาวิน)

- **Database:** Recall Surgery (data source `b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
- **Subject:** `Breast`
- **Topic:** `Lecture 15 Breast — อ.มาวิน`
- **Source:** Breast_Surgery_Summary.pdf (2 chapters), made from the 171-slide lecture deck including the lecturer's handwritten notes
- **Date:** 2026-10-26

## Counts

| Type | Ch1 Benign/approach | Ch2 Cancer | Total |
|---|---|---|---|
| MCQ | 12 | 12 | 24 |
| Flashcard | 11 | 11 | 22 |
| MEQ | 1 | 1 | 2 |
| OSCE | 1 | 1 | 2 |
| **Total** | 25 | 25 | **50** |

- **Difficulty:** 15 Easy, 25 Medium, 10 Hard.
- **MCQ key spread:** A5, B5, C4, D6, E4.
- **Status:** all 50 items are `Ready`; none are `Draft`.
- **OSCE stations:** (1) focused breast and axillary examination; (2) informed consent before breast cancer surgery (BCS + SLNB vs mastectomy).
- **MEQ cases:** (1) palpable lump → triple assessment → the lecturer's score → excision; (2) IBC/LABC → staging → neoadjuvant → MRM → PMRT → complication.

## Editorial rules for this set

- The Breast subject already had 136 items (GenSx Ch07/Ch19, Tiger sum Ch4–6). This set leans on what the lecture adds instead of repeating generic facts. Examples:
  - the lecturer's triple-assessment score (≥5, or atypia, or a growing lump → excise);
  - the six factors weighed before choosing treatment;
  - BCT contraindications the lecturer crossed out (a central/nipple tumour, and pregnancy itself);
  - the lecturer's ALND rule;
  - "systemic disease from stage I";
  - mastalgia mimics; drug- and hypothyroid-induced galactorrhoea;
  - accessory breast cancer; pregnancy-associated breast cancer.
- Lecturer-specific rules that differ from current evidence are always framed as "ตามที่อาจารย์สอน" or "taught in this course". This applies to: the ALND rule (vs Z0011/SENOMAC), lower-inner-quadrant prognosis, smoking listed as not a risk factor, imaging by age cut at 35 years, and the triple-assessment score.
- The set contains no drug doses. Staging is AJCC 8th throughout.

## What verification changed

An independent reviewer worked all 24 MCQ keys blind; 24/24 agreed. It then web-checked the guideline claims and found 2 blockers, 7 fixes and 7 nits. All were applied by scripted replacement except one nit that needed no change.

**Blockers**
- **N1 staging:** an explanation called N1 "stage IIB". In AJCC 8th, T0–1 N1 is IIA. The error came from the summary PDF, which has now been corrected.
- **Tietze syndrome:** one item equated it with costochondritis. Tietze has swelling and costochondritis does not. The PDF has also been corrected.

**Fixes**
- An MCQ stem said "modified radical mastectomy", which gave away the ALND answer.
- SLNB in pregnancy is now flagged as debated (ASCO advises against it; other guidance allows radioisotope-only mapping).
- "IIIA T3N1 = early disease" is labelled as the course's grouping.
- A nipple-discharge card gave a malignancy total that didn't match its own figures (~12%, not ~10%).
- The lobule-type card overstated the effect of pregnancy as "permanent"; type 3 predominance holds only before menopause.
- In the MEQ, a score ≥6 still requires tissue diagnosis before definitive surgery.
- The consent OSCE no longer quotes ~10% local recurrence to the patient.

**Nits**
- The NCCN menopause definition now includes prior bilateral oophorectomy.
- Poland syndrome is now keyed on absence of the pectoralis major sternal head.
- Tis (Paget) applies only when there is no underlying DCIS or invasive cancer.
- The claim that TNBC has the most stem cells is now framed as the lecturer's teaching.
- Thyroid bone metastasis is now described as destructive.
- Gynecomastia is no longer called "usually symmetric".

## Known gaps

The lecture deck does not teach the following:
- post-operative complications of breast surgery;
- peri-operative orders;
- follow-up schedules;
- reconstruction techniques beyond case photos.

Items on these topics draw only on the summary's principle-level sections. Nothing on these topics is tested at dose or schedule level.

## Notes

- Post-upload SQL verification was not run because the Notion query allowance was exhausted. Both upload calls returned 25/25 pages created synchronously, with properties echoed back.
- New rows appear in the recall app only after running `./publish.sh` in the `med-recall` folder.

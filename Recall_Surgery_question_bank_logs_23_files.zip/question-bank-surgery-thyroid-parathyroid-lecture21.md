# Question bank — Lecture 21 Thyroid & Parathyroid (อ.Pasurachate, KCMH)

- **Database:** Recall Surgery (`collection://b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
- **Subject:** Head-Neck & Endocrine
- **Topic string:** `Lecture 21 Thyroid & Parathyroid — อ.Pasurachate (KCMH)`
- **Source:** lecture slides `21_Thyroid_and_Parathyroid.pdf` (50 slides incl. handwritten notes) → Ultimate Summary PDF `Thyroid_Parathyroid_Summary.pdf` (2 chapters). No Notion source page, so `Source` is empty.
- **Built:** 2026-11-06

## Counts

| Type | Thyroid ch. | Parathyroid ch. | Total |
|---|---|---|---|
| MCQ | 13 | 5 | 18 |
| Flashcard | 12 | 6 | 18 |
| MEQ | 1 | 1 | 2 |
| OSCE | 2 | 0 | 2 |
| **Total** | 28 | 12 | **40** |

MCQ key spread: A 4 · B 4 · C 4 · D 3 · E 3. All items `Status = Ready` (no Draft).

## Editorial rules for this set

- **Lecture-specific by design.** The bank already held ~185 Head-Neck & Endocrine thyroid/parathyroid items (Board review HNB อ.จิรัฐ, GenSx Vol.1 Ch06, Tiger sum GS6 Ch1–3). Items were written around this lecturer's teaching points and cases rather than repeating those sets. No new MCQs on these, because the existing sets already cover them:
  - low TSH → scan
  - Bethesda IV → lobectomy
  - frozen section in Bethesda IV
  - hematoma
  - bilateral RLN and EBSLN injury
  - MTC and pheochromocytoma
  - PHPT surgical criteria
  - Miami criterion
  - FHH
  - tertiary-HPT surgery
  - parathyroid carcinoma
- **New angles used:**
  - the lecture's five cases (22F cyst, 60F age, 71M substernal goiter, 41F Hürthle → completion, 36F Bethesda V → lobectomy + frozen section = goiter)
  - growth over days vs months
  - hoarseness → laryngoscopy
  - Graves with a cold nodule; high TSH with a suspicious US nodule
  - choosing which nodule to aspirate
  - a cyst refilling three times
  - gross invasion found during surgery → TT
  - ATA 2025 lobectomy ≤2 cm
  - Mg-refractory hypocalcemia
  - anaplastic tumor with stridor → airway first
  - PTH before imaging
  - after transplant: secondary resolving vs tertiary
  - persistent vs recurrent HPT
  - cinacalcet's mechanism
  - severe hypercalcemia: hydration first
  - KCMH MIBI + pertechnetate subtraction scan
  - IPD vs OPD causes of hypercalcemia
- **OSCE choice:** informed consent for diagnostic lobectomy (Bethesda IV), and a POD1 ward call for post-thyroidectomy hypocalcemia. Neck-exam and hematoma stations already exist several times in the bank.
- **Practice variation not keyed as a single answer:** Bethesda III repeat FNA vs lobectomy (KCMH tends to operate). There is no MCQ on it.
- **Edition labels:**
  - Slide ROMs are kept alongside the Bethesda 2023 ROMs.
  - The slide's "malignancy → TT" is contrasted with ATA 2025 Rec 15A–C.
  - The PHPT criteria are from the 5th International Workshop 2022.
- **Doses:** only IV 10% calcium gluconate and calcitriol, both web-verified, with ⚠ formulary warnings. All other drugs are named only.

## What adversarial verification changed (1 critical, 3 major, 18 minor findings)

All 18 MCQ keys matched the reviewer's independent answers. Fixes were applied by scripted exact-string replacement in 18 items.

- **Critical, #26 FC:** removed a wrong claim that the slide ROMs (14/25/70) are the "Bethesda 2nd ed" figures. The 2017 ranges are actually 10–30, 25–40 and 50–75.
- **Major:**
  - **#7 MCQ:** distractor B ("frozen section to decide extent") could be defended. It was reworded to "frozen section of the nodule capsule to look for capsular invasion".
  - **#25 FC and #8 MCQ:** added the NIFTP exception to "papillary nuclear features = carcinoma".
  - **#38 OSCE:** the consent checklist quoted total-thyroidectomy hypocalcemia and bilateral-RLN risks for a lobectomy. It now explains that these apply if a completion/total thyroidectomy follows.
- **Minor:**
  - ATA 2025 Rec 15C is confirmed, so the "check 2025" hedges in #7 and #9 are gone.
  - #9's stem now states no radiation and no family history.
  - #8's stem now gives the nodule size.
  - #14: added PTH kinetics after transplant.
  - #11, #16, #17: ⚠ markers added.
  - Hot-nodule "<1%" is labelled as the lecturer's figure (surgical series report higher) in #2 and #21.
  - #6: added a note that ethanol ablation is used in some centers.
  - #24: added a note on 80/20 vs ROM ~30%.
  - #35: added the AAES 2016 note.
  - #36: completion thyroidectomy changed to "may be considered" (ATA 2025 Rec 16B), and hoarseness now reads "think invasion before compression".
  - #37: imaging role in tertiary HPT.
  - #39: added bedside wound opening for hematoma.
- **Known overlaps kept on purpose** (different item types): #8/#25, #10/#28, #11/#39, #24/#36/#38, #34/#37, #14/#37.

## Numbers that are lecture-only (labelled in items, not web-verified)

- EBSLN injury 20%
- RLN injury <1%
- transient hypoparathyroidism ~50%, permanent <2%
- nodule >4 cm → CA ~15%
- frozen section accuracy for PTC ~96%; FA vs FTC ~50%
- Bethesda IV 80% benign / 20% CA
- hot-nodule cancer risk <1%

The Thai vitamin D deficiency figure (60–70%) is deliberately not tested.

## Gaps the lecture did not teach (not imported)

- The slides don't cover these, so no items were written: thyroid embryology beyond the anatomy slide, MTC/anaplastic management details, RAI/TSH suppression, Graves surgery and pre-op preparation, neck dissection levels, parathyroid carcinoma, MEN syndromes beyond a mention.
- Peri-operative care and complications beyond the "risks of thyroidectomy" slide come from the summary's supplements, so only web-verified items from that material were used.

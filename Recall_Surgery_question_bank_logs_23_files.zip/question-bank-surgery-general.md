# Question bank — Hernia (Pungpapong) (Recall Surgery)

Source: "Hernia" lecture, Asst. Prof. Suppa-ut Pungpapong (Dept. of Surgery, Chula), 72 slides with handwritten annotations (decoded), plus the web-verified Ultimate Summary PDF built from it (Hernia_Surgical_Summary.pdf, Oct 2026).
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-15 (rows created 08:42:23Z–08:42:58Z). Subject = General surgery for every item. No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Hernia (Pungpapong) · Ch1 General principles | 10 | 10 | 1 | 0 | 21 |
| Hernia (Pungpapong) · Ch2 Inguinal & femoral hernia | 17 | 16 | 1 | 3 | 37 |
| **Total** | **27** | **26** | **2** | **3** | **58** |

OSCE stations: informed consent for Lichtenstein repair (8 min) · POD0 urinary retention after spinal anaesthesia in a man with BPH (6 min) · demonstrate deep-ring occlusion + invagination tests, explain limits, present the 6-point case (7 min).
MEQs: 74-year-old man, reducible left inguinal hernia + BPH → occlusion test → precipitating-factor work-up → elective decision (lecturer vs HerniaSurge WW) → mesh repair → urinary retention/recurrence · 79-year-old woman, strangulated femoral hernia with SBO → resuscitation (no taxis/truss) → WSES markers/CT → emergency timing → McEvedy vs Lockwood vs Lotheissen vs lap, bowel viability, femoral vein, mesh both positions → POD4 fever = leak/SSI not atelectasis.
MCQ key spread: A 6 · B 5 · C 5 · D 6 · E 5. Integrity: all MCQs have 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 0 duplicate Names in the DB (698 rows); all `Status = Ready`.

## Editorial rules applied
- MCQ fully English, stems 329–508 chars with vitals; lead-ins weighted to decisions (colonoscopy before repair, obstruction + reducible hernia → other cause, femoral → repair not truss, never-operated SBO → examine groins, taxis only without strangulation signs, reduction en masse → operate, peritonitis → laparotomy + preperitoneal, McEvedy for resection, lap for femoral in women and bilateral, recurrence after TEP → Lichtenstein, pregnancy → watchful waiting, POD0 retention → catheter, ischaemic orchitis, refractory CPIP → triple neurectomy, child → herniotomy, sliding/pantaloon intra-op decisions).
- No drug doses. Verified numbers only: Moreno-Egea 2000 (IIH 85%, DIH 64%, femoral 39%), CPIP 10–12%, femoral 16.7–37% of women's groin hernias, 40.6% emergency presentation (Front Surg 2019), WSES <3 cm, M3 fixation.
- Lecturer-only figures (6 hr to gangrene, bladder >6 hr, 60% contralateral PPV, deep ring 2 cm, 6-week fascia healing, 2-month activity limit, slide epidemiology %) not used in any item.
- Practice variation kept out of MCQ keys and stated both ways in flashcards/MEQ: mesh vs tissue repair after bowel resection (lecture vs WSES 2017), watchful waiting in minimally symptomatic men, lap vs Lichtenstein for primary unilateral (HerniaSurge 2023), activity restriction, antibiotic prophylaxis.

## What verification changed
Independent reviewer answered all 28 draft MCQs blind — 28/28 agreed with keys. 3 must-fix, 12 should-fix, 9 nit; applied by scripted replacement:
- MUST: CPIP stem moved from 9 to 18 months and made debilitating (Alfieri 2011: wait ≥1 year before surgery); Richter key no longer names "femoral hernia" (gave away the diagnosis) and stem excludes a leg/perineal infection source; ischaemic-orchitis stem now gradual from POD2 with normal testicular lie (excludes torsion).
- "Urinary retention = most common complication" attributed to the lecturer in 3 items (not in HerniaSurge).
- Women flashcard: 40.6% tied to femoral hernias in women; HerniaSurge "suggests" (weak) lap.
- Lesser-sac malrotation claim attributed to lecturer; Littre/Amyand "emergency" only when content inflamed; Hesselbach floor includes conjoint tendon medially.
- Near-duplicates resolved: one femoral-elective MCQ rewritten as femoral approach (lap) question; obstruction-with-reducible-hernia duplicate replaced by pregnancy round-ligament varicosities MCQ; second Richter femoral MCQ deleted (59 → 58); peritonitis-approach cue removed from another explanation; WSES flashcard re-scoped to contaminated/dirty; Littre/Amyand flashcard re-scoped to de Garengeot.
- Three length-cued keys shortened; Lotheissen explanation softened; appendectomy-mechanism explanation notes a standard McBurney incision has not been shown to raise risk; one MEQ no longer decides WW vs surgery on one symptom.

## Known gaps — deliberately not tested
- Antibiotic prophylaxis drug/timing; anticoagulant management; anaesthetic doses.
- Bassini/Darn/TEP-vs-TAPP steps only as distractors/explanations; herniotomy steps not carded.
- Triangle of doom not re-carded (exists in UGI-MIS set); saphenous varix, psoas abscess, aneurysm not tested individually.
- Diagnostic laparoscopy after spontaneous reduction skipped (existing UGI-MIS MCQ).
- Ventral hernias (epigastric, umbilical in adults) only lightly — the lecture lists them without teaching.
- Pediatric hernia beyond "herniotomy, no mesh"; contralateral exploration (contested).

## Overlap with other sets (same Subject)
UGI-MIS Ch13 Abdominal wall hernia (12 items): groin-lump exam OSCE, strangulated inguinal MEQ, obturator MCQ, spontaneous-reduction MCQ, incarcerated viable repair MCQ, recurrence-after-Lichtenstein MCQ, triangle-of-doom card. This set's recurrence MCQ is the mirror (after TEP). Filter by Topic to drill one lecture.
Within-set pairs to watch: strangulation + peritonitis next-step MCQ ↔ approach MCQ; femoral SBO MCQs (examine groins / McEvedy) ↔ femoral MEQ; urinary retention MCQ ↔ OSCE ↔ Ch1 MEQ Q5.

## Retiring this set
Filter `Topic LIKE 'Hernia (Pungpapong)%'` (rows created 2026-10-15 08:42:23Z–08:42:58Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

# Question bank — Surgical Nutrition (Phuphat Vongwattanakit) (Recall Surgery)

- **Database:** Recall Surgery (`collection://b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
- **Subject:** Perioperative care (every item — user's choice)
- **Topic prefix:** `Surgical Nutrition (Phuphat) · ChN …`
- **Uploaded:** 2026-11-02, rows created 01:43:43Z–01:43:54Z. No `Source` URL.
- **Sources:** lecture slides "16.1 Surgical Nutrition" (61 slides with handwritten notes) and the web-verified Ultimate Summary PDF built from them (Surgical_Nutrition_Summary.pdf, 1 Nov 2026, 35 pages).
- **Status:** all 45 items `Ready`; none left as `Draft`.

## Counts (checked by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Malnutrition screening & assessment | 6 | 7 | 1 | 1 | 15 |
| Ch2 Nutritional requirements | 6 | 6 | 1 | 0 | 13 |
| Ch3 EN, PN & refeeding | 8 | 7 | 1 | 1 | 17 |
| **Total** | **20** | **20** | **3** | **2** | **45** |

- MCQ key spread: A 5 · B 4 · C 3 · D 4 · E 4. Stems are 365–539 characters and all include vitals.
- Difficulty: Easy 11 · Medium 26 · Hard 8.
- Integrity: every MCQ has 5 choices, a Correct and an Explanation; both OSCEs have Checklist and Minutes; every non-MCQ has an Answer. There are 0 duplicate Names in the database (3,024 rows).
- **MEQs:**
  - Ch1: malnourished sigmoid cancer listed for elective sigmoidectomy — screen, assess, postpone, choose the route, post-op feeding and leak.
  - Ch2: POD 4 peritonitis patient — weight-based vs Harris-Benedict energy, critique of factor stacking, nitrogen balance, NPC:N, overfeeding.
  - Ch3: prolonged ileus after low anterior resection in a malnourished woman — PN indication, central vs peripheral access, refeeding-safe start (NICE and ASPEN both named), monitoring, catheter sepsis with leak excluded.
- **OSCEs:**
  - Nutrition screening and assessment of a patient admitted for elective gastrectomy (Thai 4 questions, NAF elements, action).
  - Day-3 refeeding syndrome on full-target TPN in a man with chronic alcohol use.

## Editorial rules applied

- Only facts the summary states as verified were tested. Anything marked "เชิงหลักการ" was not keyed.
- Where the slide was wrong or outdated, the key uses the verified value and the explanation names the slide's value:
  - Harris-Benedict female constant 655.1 (the slide prints 65.1)
  - Hepatic encephalopathy: no protein restriction, 1.2–1.5 g/kg (ESPEN 2019; slide 0.5)
  - Hemodialysis protein 1.0–1.2 g/kg (KDOQI 2020; slide 1.1–1.5 — not offered as an option, so only one answer is defensible)
  - Albumin treated as a prognostic / high-metabolic-risk marker, not a diagnostic marker of malnutrition
- No item keys a single starting kcal or thiamine dose where NICE and ASPEN differ. The refeeding MCQ keys "thiamine first, low start, slow increase, close monitoring" with no number.
- Angles already in the bank (Tiger sum GS1 Ch5, Metabolic response to injury) were avoided. Examples: the albumin-after-surgery MCQ, the GLIM "which finding is required" item, abrupt-PN-stop hypoglycemia, PNALD in short bowel, the fistula route, and immunonutrition timing.

## What verification changed

The reviewer answered all 20 MCQs blind and agreed with all 20 keys. It re-checked every calculation (HB 1,291 and 1,508 kcal; N balance −5.6 and −7; NPC:N 250:1 and 107:1). It made 26 findings: 2 must-fix, 8 should-fix and 16 nits. 21 fixes were applied by script and no key changed.

- **Must-fix — refeeding OSCE:** the Answer and Checklist cited "BMI < 16" for a BMI of 16.5. Both were rewritten: high risk via intake >10 days (NICE set 1), plus BMI <18.5 and alcohol (set 2).
- **Duplicates removed:**
  - Ch3 MEQ Q5 re-tested PN-associated liver injury; it is now catheter sepsis with leak excluded on CT.
  - A Ch3 flashcard's ICU early-EN line duplicated a Metabolic-response card; it now tests the ESPEN 2025 perioperative rule (≥5 days NPO, or <50% for >7 days).
- **Source consistency:**
  - Ch3 MEQ Q1 now uses ESPEN 2025 instead of the slide's ">7–10 days" for a post-op patient.
  - Ch3 MEQ Q3 names both NICE and ASPEN starting values.
  - Ch1 MEQ Q2 no longer grades malnutrition from albumin.
- **MCQ hygiene:**
  - A 2-day illness duration was added to the obese-pancreatitis screening stem, so the screen count is determinate.
  - The MUST rationale was reworded.
  - A vitamin-C distractor that also fitted was replaced.
  - "Despite a prokinetic" was added to the NJ-tube stem.
  - A key that was much longer than the other options was shortened.
  - Two esophageal-cancer stems were given different demographics.
- **Safety notes:** ⚠ formulary notes were added to the energy targets in a Ch2 flashcard and the Ch2 MEQ. The bacterial-translocation caveat (weak human evidence) was added to the "why EN first" card.
- **Not applied:**
  - The reviewer queried "minimum 7 days" for pre-op PN. It was kept: the ESPEN 2025 full text (Rec 27) reads "10–14 days with a minimum of seven days (GPP)".
  - Overlap nits were accepted as application items: NAF cut-offs appear 4 times; nitrogen balance and overfeeding each appear in an MCQ and the MEQ.

## Known gaps (the source did not teach or verify these; not imported)

- Surgical relevance of micronutrients: zinc in fistulas, B12 after gastrectomy, vitamin K in obstructive jaundice. The summary's column is principle-level, so only the slide's function column was keyed.
- kcal/g values, the C:P:F fat range (30–60%, moderate confidence), and details of MST/MUST/NRS-2002.
- *C. difficile* and sorbitol in EN diarrhea, CXR confirmation before the first NG feed, central-line insertion complications, tapering PN, and catheter-sepsis management steps.
- Thiamine treatment dose for established Wernicke, home PN in incurable cancer (practice variation), the ESPEN vs ASPEN gap in ICU PN timing, and PEG vs NG aspiration risk.
- The NAF action timelines (7 d / 3 d / 24 h) come from the slide's NAF form; the cut-offs 5 and 11 are confirmed by Komindr 2013.

## Retiring this set

Filter on `Topic LIKE 'Surgical Nutrition (Phuphat)%'` (rows created 2026-11-02 01:43:43Z–01:43:54Z). The MCP cannot delete pages, so move the rows to a "🗑 ชุดเก่า" page under the Surgery course page.

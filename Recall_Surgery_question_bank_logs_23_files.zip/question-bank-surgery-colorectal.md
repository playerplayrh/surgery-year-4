# Question bank — Colorectal Cancer (Sahakitrungruang)

Recall Surgery DB · Subject **Colorectal & Anal** · Topic `Colorectal Cancer (Sahakitrungruang)` · uploaded 2026-10-26 · all Status `Ready`

Source: lecture slides "Colorectal Cancer" (ศ.นพ.ชูชีพ สหกิจรุ่งเรือง, Chula) + the Ultimate Surgical Summary PDF built from them (`Colorectal_Cancer_Surgical_Summary.pdf`). No Notion source page, so `Source` is empty.

## Counts

| Type | n |
| --- | --- |
| MCQ | 18 (keys A4 · B4 · C4 · D3 · E3) |
| Flashcard | 18 |
| MEQ | 1 (lecture index case, 5 parts) |
| OSCE | 3 (DRE · consent for LAR + diverting ileostomy · POD 5 post-op review) |
| **Total** | **40** |

Separate from the older 20-item set `GenSx Vol.1 Ch12 Colorectal Cancer` (same Subject).

## Editorial rules applied

- MCQ in English only, full vignettes with vitals; Flashcard/MEQ/OSCE in Thai with English terms.
- Only dose in the set: slide's long-course CCRT 50.4 Gy (MEQ, with ⚠ formulary note). No antibiotic or anticoagulant doses.
- Staging items state AJCC 8th edition (still current for colon & rectum per ACS/AJCC 2026 list).
- Not tested as single answers: robotic vs lap superiority, watch-and-wait vs TME, CME survival benefit, drain use, ileostomy closure timing.

## What verification changed (adversarial review: 18/18 MCQ keys agreed; 2 must-fix, 8 should-fix, 15 minor)

- Malignant-polyp MCQ: "head of the polyp (Haggitt 2)" → "neck of the polyp (Haggitt 2)" (head = level 1).
- Perforated sigmoid MCQ: stem now says perforation **at the tumor site**, cecum intact — otherwise a sigmoid Hartmann would leave the perforation behind.
- Index-case MCQ + MEQ: removed the unsupported "fixed to the pelvic wall"; MRI = threatened MRF (cT3), no sphincter involvement.
- Diverting loop ileostomy: "reduces leak severity but not occurrence" was wrong — RCT meta-analysis shows fewer clinically relevant leaks and reoperations. Fixed in MEQ, consent OSCE **and in the summary PDF**.
- dostarlimab MCQ: added phase-2/12-patient caveat + NCCN (v1.2023 onward) preference for checkpoint inhibitor in dMMR LARC; removed a meaningless dosing note.
- ROLARR/COLRAR flashcard: dropped unverified "COLRAR costlier/longer"; added REAL trial (JAMA 2025) counter-evidence (3-yr LRR 1.6% vs 4.0%).
- Pathways flashcard: added the trap "MSI-H overall ~15%, mostly sporadic MLH1 hypermethylation".
- OSCE checklists: consent now includes possible permanent stoma and alternatives; DRE includes sphincter tone; POD-leak OSCE patient changed to avoid duplicating the MCQ.
- Minor wording fixes: Hohenberger cohort description, CRM vs MRF terminology, upper-rectum scope of the 5-cm mesorectal rule, hepatic-flexure naming variation note.
- Not applied: Turcot subtype detail (outside the source).

## Kept but worth knowing

- HNPCC risk card (78% / 43%) is labelled "ตามสไลด์อาจารย์" and notes the data are old and gene-dependent.
- Stage 5-yr survival and Hohenberger numbers are tested as slide figures only.

## Gaps the source did not teach (not imported)

- Haggitt/Kikuchi depth cut-offs, cecal diameter perforation threshold, distal-bowel-margin numbers for low rectal cancer, drainage size cut-offs, the en-bloc "80%" note (text incomplete on slide).
- DRE technique steps — the DRE OSCE uses generic exam-skill actions only.
- Peri-op care and complications were not in the lecture slides; items on those draw only on canonical points stated in the summary.

## Verification status

Both upload batches reported 20/20 pages created; spot-fetch of an MCQ and the MEQ confirmed fields intact. The SQL integrity check (counts by Type, duplicate Names, per-type fields) could not run on 2026-10-26 because the Notion query allowance was exhausted — rerun later.

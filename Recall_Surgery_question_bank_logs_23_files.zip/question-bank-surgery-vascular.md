# Question bank — Surgery · Vascular · CVD lecture (อ.อภินันท์)

Run date: 2026-10-29 · Target: Notion **Recall Surgery** (data source `b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
Topic string: `CVD lecture (อ.อภินันท์) · Chronic Venous Disease & Management` · Subject: `Vascular` · Status: all `Ready`

## Source
- CVD summary PDF built from อ.อภินันท์'s annotated slides (Chula vascular surgery, lecture 12 ต.ค. 2569) + guideline facts verified at the time (ESVS 2022, SVS/AVF/AVLS 2022, AVF/SVS 2021 EHIT, EVRA, CEAP 2020)
- Lecture-audio transcript (Whisper large-v3, cleaned) — used for the lecturer's spoken points
- No `Source` URL (no Notion page for this lecture)

## Counts (verified by SQL in Notion)
| Type | Count |
|---|---|
| MCQ | 20 (keys A–E × 4 each) |
| Flashcard | 16 |
| MEQ | 1 |
| OSCE | 3 |
| **Total** | **40** |

All 20 MCQs: 5 choices + Correct + Explanation; all OSCE have Checklist + Minutes; no duplicate Names.

## Overlap policy
The DB already held 41 CVD items (Tiger sum GS5 Ch3 = 21, GenSx Vol.1 Ch18 = 20). This set was written to test what only this lecture adds: Mickey Mouse / Egyptian eye signs, monophasic CFV flow → iliac obstruction, Klippel-Trenaunay, CEAP 2020 additions (C2r, C4c, C6r), the classroom case C2 Ep As Pr, treatment sequence, SSV indications, four-layer bandage, stocking class 1, venoactive drugs (Reparil oral vs gel, sulodexide), sclerotherapy role and PFO contraindication, endovenous candidate criteria and contraindications, catheter tip ~2 cm from SFJ, tumescent functions, RFA parameters, bail-out technique, EHIT I–IV management, EVRA, continuing anticoagulation for EVTA.

## Editorial rules applied
- MCQ English-only, full vignettes with vitals; flashcards Thai, ≤3 lines
- Not used as the deciding point of any MCQ (practice variation): stocking duration after ablation, ABI 0.5 (slide) vs 0.6 (ESVS), perforator cut-off 0.35 vs 0.5 s
- Not tested: tumescent recipe volumes, laser settings, foam air ratio (institutional / unclear audio)

## What adversarial review changed (21 edits; reviewer agreed with all 20 MCQ keys)
- **Obstruction-first sequence reframed as practice variation**: the lecture says correct obstruction first; SVS/AVF/AVLS 2023 Part II (Guideline 5.1.2, weak, C2) suggests superficial first. MCQ on iliac stenting now asks which intervention treats the cause of venous claudication; OSCE duplex station and two explanations softened
- Horse chestnut: oral form "edema and leg pain" (Cochrane CD003230) — the lecturer's "edema only" was an overstatement; ulcer healing still not improved
- Neuropathic ulcer stem: ABI 1.4 → 1.5 (1.4 is still within normal)
- MEQ moved from C4c to C4a to avoid duplicating the C4c MCQ
- EHIT III grade noted as inconsistent in the AVF/SVS 2021 document (summary 1B vs body 2C)
- Foam flashcard rewritten (ESVS: UGFS suits trunk <6 mm); SSV flashcard requires duplex-proven SSV reflux; thrombophilia marked "per slide" (guidelines individualise VTE risk)
- Lead-ins tightened (cyanoacrylate item, CEAP item), Mickey Mouse ear labelling caveat added, KTS explanation corrected

## Draft items
None.

## Known issues / gaps
- **Inconsistency between older sets already in the DB**: Tiger sum MEQ uses perforator reflux >0.35 s, GenSx Ch18 MEQ uses >0.5 s. Both appear in sources; current SVS/AVF uses ≥500 ms
- The lecture did not teach: venous claudication workup details, deep venous valve reconstruction, recurrence management after ablation, lymphedema management — not imported
- Four iliac-obstruction items now exist across sets (existing May-Thurner stent MCQ + this set's MCQ ×2 + OSCE) — acceptable across formats

## Publishing
New rows reach the recall app only after `./publish.sh` is run in the `med-recall` folder.

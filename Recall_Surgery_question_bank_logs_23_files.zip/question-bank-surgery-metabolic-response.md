# Question bank — Metabolic response to injury (Vacharathit)

- **Database:** Recall Surgery (`collection://b246fd75-4eb3-4221-ab0d-4d51608eed3b`)
- **Subject:** Perioperative care
- **Topic string:** `Metabolic response to injury (Vacharathit)`
- **Built:** 2026-10-26
- **Sources:**
  - Lecture slides "8 Metabolic response to injury" (32 slides, with the lecturer's handwritten notes)
  - The v5 clinical summary PDF made from those slides, with guideline facts checked by web search
- **Status:** all 30 items `Ready`; none left as `Draft`

## Counts

| Type | n | Notes |
|---|---|---|
| MCQ | 14 | English USMLE/NL vignettes; keys A3 B3 C3 D3 E2 |
| Flashcard | 13 | Thai structure with English terms; ≤3 lines |
| MEQ | 1 | Lecturer's Case 2 (abdominal sepsis after re-laparotomy, glucose 300s on sliding scale) |
| OSCE | 2 | Post-op review of new hyperglycemia + tachycardia; nutrition plan for SBO on NOM (PN, not NG) |
| **Total** | **30** | Difficulty: Easy 11 · Medium 18 · Hard 1 |

## What the set covers

- **Framing:** the lecturer's 3-goals framework, plus ebb, flow and recovery phases
- **Mediators:**
  - TNF-α, IL-1 and IL-10
  - Counter-regulatory hormones, and the anabolic signals that fall
- **Fuel:**
  - Why muscle glycogen can't feed blood glucose
  - Gluconeogenesis substrates
- **Stress hyperglycemia:** the mechanism, and new hyperglycemia + tachycardia as an early sign of sepsis or leak
- **Starvation vs stress:** the metabolic profile of each, and the REE curve by type of injury
- **Elective vs accidental injury:** how the stress response differs, and the avoidable factors that amplify it
- **Albumin and other markers:**
  - Albumin as a negative acute phase reactant
  - Half-lives of the visceral proteins
  - GLIM 2019
- **Glucose control:** SCCM 2024 thresholds and targets, NICE-SUGAR, continuous IV insulin vs sliding scale
- **ICU nutrition:**
  - ASPEN 2021 energy and protein targets
  - ESPEN ICU 2019 timing of EN and PN
  - Route choice in mechanical SBO
- **Peri-op nutrition (ESPEN surgery):** pre-op fasting times and immunonutrition
- **Therapies:** growth hormone is harmful (Takala 1999)
- **Refeeding syndrome:** ASPEN 2020 definition and grading

## Editorial rules applied

- Only facts from the slides, the lecturer's notes, or guideline points checked by web search were tested.
- Anything the summary marks "เชิงหลักการ" (principle-level, unverified) was not tested.
- These were deliberately not tested:
  - Thiamine dose and refeeding starting kcal
  - NRS-2002/NUTRIC cut-offs
  - REDOXS
  - Trials of biologics in sepsis
  - BCAA
  - How often to check K⁺
- To avoid repeating the existing "GenSx Ch01 Systemic response to injury" and "Tiger sum GS1 Ch5 Surgical Nutrition" sets, these were skipped or tested from a different angle:
  - Sepsis-3 definitions
  - Caloric-table arithmetic
  - IL-6 dual role
  - Hypophosphatemia as the main refeeding electrolyte
  - The "<50% intake >7 days" criterion
  - Feeding in unstable shock
  - Ebb vs flow energy expenditure
- The fuel-reserve kcal values and gluconeogenesis precursor percentages were not tested as numbers, because the slide figure is illustrative.

## What verification changed

The reviewer answered every MCQ before seeing the key and agreed with 13 of 14 keys. It made 17 findings: 1 critical, 2 major and 14 minor.

- **Critical — immunonutrition MCQ:**
  - The ESPEN guideline on clinical nutrition in surgery, **Update 2025** (Rec 19, grade B), now offers immunonutrition "preoperatively or perioperatively" for major tumour surgery.
  - That made the old distractor "preoperatively only" defensible, so it was replaced.
  - The key was reworded to "perioperatively, starting before surgery and continuing afterwards", and the explanation now cites the 2025 update.
- **Major — OSCE on post-op hyperglycemia:**
  - The SCCM 2024 ICU target of 140–200 was being applied to a ward patient.
  - It now says "target per the ward protocol; ICU 140–200".
- **Major — MEQ sub-question 3:**
  - The model answer stated as fact that dextrose spares protein in acute stress.
  - It now presents this as the lecturer's reasoning, with the caveat that glucose only partly suppresses proteolysis in stress.
  - The same caveat was added to MCQ explanation #0.
- **Minor fixes:**
  - Wording of the refeeding-risk claim
  - ESPEN's 850 mOsm/L noted next to ASPEN/MSD's ≤900 for peripheral PN
  - Ebb phase no longer described as "everything decreases"
  - Thiamine deficiency added to the severe refeeding grade
  - One compound OSCE checklist item simplified

## Flag on an existing item (not changed)

- An existing "Tiger sum · GS1 Ch5 Surgical Nutrition" MCQ (peripheral PN, POD 9 after pancreaticoduodenectomy) reportedly keys osmolarity "<650 mOsm/L" and treats 900 as wrong.
- The reviewer found that ASPEN and the MSD Manual give ≤900 mOsm/L, and ESPEN gives 850. No major source found uses 650.
- Only the stem and key letter could be seen, not the choices, so check that item's options by hand.
- The ESPEN 2025 surgery update may also affect older surgery-nutrition items that reject "preoperative-only" immunonutrition.

## Known gaps (the source did not teach these; not imported)

- Refeeding management numbers (thiamine dose, starting kcal, electrolyte replacement)
- Nutrition screening-tool cut-offs (NRS-2002, NUTRIC)
- Indirect calorimetry technique
- PN composition and complications beyond hyperglycemia and line infection
- Specifics of peri-op insulin protocols. The lecturer's note "NPO for surgery → off insulin" is not tested as a single right answer, because practice is to adjust per protocol.

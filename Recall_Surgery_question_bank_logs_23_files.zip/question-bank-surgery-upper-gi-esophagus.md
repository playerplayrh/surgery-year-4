# Question bank — Esophagus (อ.ชฎิล ธราเวช) (Recall Surgery)

Source: lecture "Esophagus", อ.ชฎิล ธราเวช (94 slides, annotated) + the web-verified Ultimate Summary PDF built from it (Esophagus_Surgical_Summary.pdf, 2026-10-23).
Target: Notion data source `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-26 (~02:30Z). No `Source` URL (lecture has no Notion page).
Subject: `Upper GI` for all. Topic prefix: `Esophagus (อ.ชฎิล) · ChN …`.
Mode chosen by Waritnun: **full standalone set** (overlaps on purpose with Board review UGI-MIS and Tiger sum GS3 esophagus items; no Name is an exact copy).

## Counts (from the uploaded files; all 3 upload batches reported 20/20 created)

| Type | n |
|---|---|
| MCQ | 26 |
| Flashcard | 26 |
| MEQ | 6 |
| OSCE | 2 |
| **Total** | **60** |

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Approach to dysphagia | 3 | 4 | 1 | – | 8 |
| Ch2 Esophageal cancer | 7 | 6 | 1 | 1 | 15 |
| Ch3 Achalasia & motility disorders | 5 | 5 | 1 | – | 11 |
| Ch4 Perforation & Mallory-Weiss | 5 | 4 | 1 | 1 | 11 |
| Ch5 Caustic injury | 3 | 3 | 1 | – | 7 |
| Ch6 GERD | 3 | 4 | 1 | – | 8 |

OSCE stations: informed consent for esophagectomy after neoadjuvant therapy (cT3N1M0 SCC) · ER initial management of suspected Boerhaave (8 min).
MCQ key spread: A 5 · B 5 · C 5 · D 6 · E 5. Difficulty: Easy 15 · Medium 30 · Hard 15. All `Status = Ready`, none Draft.

## Editorial rules applied
- MCQ fully English, vignettes 200–550 chars with vitals; lead-ins weighted to surgical decisions.
- Flashcards ≤3 lines / ≤350 chars; Names made lecture-specific (often "(อ.ชฎิล)") to avoid clashing with existing short card names.
- No drug doses anywhere. Staging = AJCC 8th.
- Slide claims flagged uncertain in the summary were not tested as fact: gastrectomy for delayed gastric emptying, Toupet 220–250°, "dysplasia → CA ~5 yr", "adeno better prognosis", Botox "investigational", antibiotics in caustic injury, surveillance intervals.
- Where slides are outdated, keyed to current evidence and the explanation names the slide answer: ESOPEC (FLOT > CROSS for adeno), JCOG1109 (DCF for SCC), POEM as first-line/type III, CT-first caustic assessment (WSES 2019), Lyon 2.0 vs DeMeester.

## What verification changed
Independent reviewer answered all 26 MCQs blind — 26/26 agreement. 18 findings (1 must-fix, 8 should-fix, 9 nit), 34 scripted patches applied, validator clean afterwards:
- Must-fix: MEQ on septic Boerhaave sent hypotensive patient to CT → now "CT only after hemodynamic response + ICD; otherwise OR". Same caveat added to the Boerhaave OSCE.
- Caustic MCQ stem: hypotensive patient already imaged → post-resuscitation vitals.
- RYGB-for-obese-GERD explanation softened to ACG 2022 wording ("suggest consideration", conditional). Note: the Esophagus summary PDF ch6 carries the same overstatement.
- Toupet MCQ: stem changed to absent contractility so Nissen vs Toupet isn't practice variation; Dor wording fixed.
- Caustic stricture "smooth vs irregular" contradiction (source chapters disagree) → descriptor dropped in 3 items.
- Near-duplicates removed: second pseudoachalasia MCQ rewritten as type III → POEM; a 5th "CT esophagography for perforation" MCQ rewritten as cervical perforation → left neck drainage along SCM; overlapping LES flashcard retargeted.

## Known gaps / not tested
- Verification SQL (counts/integrity/duplicates in Notion) could not run on 2026-10-26: Notion Query Data Source allowance exhausted. Two rows spot-checked by fetch (Flashcard Ch2, MEQ Ch6) — correct. Re-run the SQL checks later: `Topic LIKE 'Esophagus (อ.ชฎิล)%'` should give 60 rows, MCQ Choices with 4 newlines, OSCE Minutes = 8.
- Not tested (practice variation / not settled in source): pyloric drainage, contrast study before oral intake, drain/diet timing, bougie size, Barrett surveillance intervals, T1a endoscopic-resection criteria detail, Pittsburgh score items, chylothorax TG cut-off.
- Overlap with existing esophagus items (Board review UGI-MIS Ch2–5, 9; Tiger sum GS3 Ch4–7) is intentional per the user's choice.

## Retiring this set
Rows created 2026-10-26 ~02:30Z; filter `Topic LIKE 'Esophagus (อ.ชฎิล)%'`. MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

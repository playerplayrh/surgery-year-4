# Question bank — Stomach & Duodenum (Udomsawaengsup) (Recall Surgery)

Source: "Stomach and Duodenum" lecture, Suthep Udomsawaengsup MD (Advanced Laparoscopic & Bariatric Surgery), 69 annotated slides — via the verified Ultimate Summary PDF built from it (Oct 2026, 4 chapters).
Target: Notion data source `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-26 (~02:20–02:30Z). No `Source` URL (no Notion page for the slides).
Subject: `Upper GI` for all rows. Topic prefix: `Stomach & Duodenum (Udomsawaengsup) · ChN …`.

## Counts (verified by SQL after upload)

| Topic | MCQ | Flashcard | MEQ | OSCE | Total |
|---|---|---|---|---|---|
| Ch1 Anatomy, physiology & PUD | 10 | 11 | 1 | 1 | 23 |
| Ch2 PUD complications — perforation, bleeding & GOO | 12 | 11 | 1 | 1 | 25 |
| Ch3 Gastric neoplasms — adenocarcinoma, GIST & lymphoma | 12 | 12 | 1 | 1 | 26 |
| Ch4 Bariatric & metabolic surgery | 6 | 6 | 1 | 0 | 13 |
| **Total** | **40** | **40** | **4** | **3** | **87** |

MCQ key spread: A 9 · B 8 · C 8 · D 7 · E 8. Difficulty: Easy 26 · Medium 44 · Hard 17. All `Status = Ready`, none Draft.

MEQs: 61y benign type I GU + H. pylori + NSAIDs (Ch1) · late elderly perforated GU → POD leak vs abscess (Ch2) · elderly GOO from antral cancer → staging → D2 or GJ/stent → POD6 duodenal stump leak (Ch3) · BMI 52 through KCMH obesity pathway → POD2 leak (Ch4).
OSCE: history-taking in chronic dyspepsia (8 min) · informed consent for emergency PPU surgery (8 min) · focused exam for metastatic signs of gastric cancer (7 min).

## Editorial rules applied
- MCQ fully English, vignettes 200–550 chars with vitals; flashcards ≤3 lines/≤350 chars; MEQ uses real newlines; OSCE 12–16 checklist items.
- Overlap with the อ.ธราธร board-review Upper GI set (99 related rows) avoided: writers were given that set's question list and tested different decision points.
- Outdated slide answers keyed to current guidance, slide answer named in the explanation: AJCC 8th N categories (old slide N table only as a trap); MALT lymphoma HP+ → eradication (not gastrectomy); rebleed → TAE before surgery in stable patients; Asian bariatric criteria (lecturer) vs ASMBS/IFSO 2022 always named in the stem.
- No numeric drug doses anywhere; regimen items carry the formulary note.

## What verification changed
Independent reviewer answered all 41 MCQs blind — 100% agreement with keys. 21 scripted fixes over 15 items + 1 deletion:
- Must-fix: PPU giant DU MCQ had two defensible answers (omental patch alone) → distractor replaced, WSES wording corrected. Maastricht VI regimen error (concomitant therapy is the fallback when bismuth is unavailable, not the low-resistance choice) fixed in an MCQ and the Ch1 MEQ. CCK origin corrected (duodenum, not distal gut).
- Should-fix: vagotomy stem no longer contradicts the pyloroplasty-closure items; GU acid "variable"; HSV preserves the main nerve of Latarjet + crow's foot; vitals added to three Ch2 stems.
- Deleted one Ch1 MCQ that duplicated an MCQ and the Ch1 MEQ (≥60y + weight loss → EGD).
- The two source errors (Maastricht VI low-resistance regimen; CCK origin) were also corrected in the summary PDF and it was re-rendered.

## Verification in Notion
SQL check 2026-10-26 03:38Z: 87 rows (Ch1 23 · Ch2 25 · Ch3 26 · Ch4 13; MCQ 40 · Flashcard 40 · MEQ 4 · OSCE 3), all Subject `Upper GI` + Status `Ready`. All 40 MCQs have 5 choices (4 newlines) + Correct + Explanation; all 3 OSCE have Checklist + Minutes; every non-MCQ row has Answer. 0 duplicate Names across the whole database.

## Known gaps — deliberately not tested
- Practice variation: omental patch vs simple closure, drains, diet start, vagotomy at emergency surgery, bougie size / limb length, follow-up EGD interval.
- Source-flagged unverified: rapid urease test sheet numbers, Borrmann type 2 "most common", Japanese screening age, gastrectomy margin cm, small (<2 cm) GIST surveillance criteria, MATTERHORN approval in Thailand, full AJCC 8th stage grouping, Thai dyspepsia guideline.
- Lecturer rule vs ACG for <60 without alarm features (drug trial vs test-and-treat) — only described in the OSCE/MEQ, not an MCQ.
- GOO fluid choice (0.9% NaCl + KCl) not re-tested here; already covered by the อ.ธราธร set.
- The lecture does not teach generic peri-op care (antibiotic/VTE prophylaxis, ERAS) — no items.

## Retiring this set
Filter `Topic LIKE 'Stomach & Duodenum (Udomsawaengsup)%'` (created 2026-10-26 after ~02:15Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

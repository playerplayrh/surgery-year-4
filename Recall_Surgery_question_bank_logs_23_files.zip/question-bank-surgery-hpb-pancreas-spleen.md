# Question bank — Pancreas & Spleen (Kitisin) (Recall Surgery)

Source: "Pancreas and Spleen" lecture, Krit Kitisin MD (KCMH), 57 slides with handwritten annotations, plus the web-verified Ultimate Summary PDF built from it (Pancreas_Spleen_Surgical_Summary.pdf, Oct 2026). Items were written from the summary text, chapter by chapter.
Target: Notion `Recall Surgery` (b246fd75-4eb3-4221-ab0d-4d51608eed3b). Uploaded 2026-10-21 (rows created after 02:17:16Z). Topic prefix: `Pancreas & Spleen (Kitisin) · ChN …`. Subject = Hepatobiliary & Pancreas (HPB) for every item (incl. spleen chapter, by user choice). No `Source` URL.

## Counts (verified by SQL after upload)

| Chapter (Topic) | MCQ | FC | MEQ | OSCE | n |
|---|---|---|---|---|---|
| Ch1 Pancreas anatomy, embryology & physiology | 8 | 10 | 1 | 0 | 19 |
| Ch2 Acute pancreatitis | 12 | 10 | 1 | 1 | 24 |
| Ch3 Chronic pancreatitis | 7 | 8 | 1 | 0 | 16 |
| Ch4 Pancreatic cancer | 10 | 9 | 1 | 2 | 22 |
| Ch5 Pancreatic cystic neoplasm | 9 | 8 | 1 | 0 | 18 |
| Ch6 Spleen & splenectomy | 4 | 5 | 1 | 0 | 10 |
| **Total** | **50** | **50** | **6** | **3** | **109** |

OSCE stations (8 min each): AP initial assessment + admission order (BISAP/Revised Atlanta, moderate LR, no prophylactic antibiotics, early feeding, US) · informed consent for Whipple · POD 8 post-Whipple ward review (DGE, drain amylase, sentinel bleed → CTA).
MEQs: POD 6 high-output distal-pancreatectomy stump fistula → NAGMA → PJ vs stump leak physiology → station 10 · alcoholic severe AP → ICU/ACS → infected necrosis step-up → pseudoaneurysm bleed · calcific CP → ESCAPE → Frey → long-term · body/tail PDAC → staging laparoscopy → DP + splenectomy → biochemical leak → adjuvant · incidental BD-IPMN → Kyoto surveillance → WF → EUS → HRS → Whipple · stable splenic injury with blush → NOM/angio → failure → splenectomy → POD 4 fever → vaccines.
MCQ key spread: A 10 · B 11 · C 10 · D 10 · E 9. Stems 333–517 chars, all with vitals. Integrity: every MCQ has 5 choices + Correct + Explanation; OSCEs have Checklist + Minutes; non-MCQ all have Answer; 109 distinct Names; all `Status = Ready`.

## Editorial rules applied
- MCQ fully English; lead-ins weighted to decisions (ERCP vs not, cholecystectomy timing, step-up/drainage route and timing, resectability → upfront vs neoadjuvant vs systemic, which operation in CP, resect vs survey cysts, NOM vs splenectomy).
- No drug doses in MCQs; fluid rates appear only in the AP MEQ with ⚠ verify; PERT/chemo regimens named only.
- Frameworks named where the key depends on them: Revised Atlanta 2012, BISAP, Ranson (gallstone vs non-gallstone sets), Balthazar CTSI, ACG 2024, APEC, POINTER, ESCAPE, AJCC 8th (vs 7th in slides), NCCN resectability, ISGPS 2016/2007, PRODIGE 24, van der Gaag 2010, Kyoto 2024, WSES 2017, ASH 2019/2026.
- Slide corrections keyed to the current answer: Atlanta 1992 → Revised 2012; aggressive fluids → moderate goal-directed LR; NJ default → NG/oral; AJCC 7th → 8th; ESWL wording.
- Deliberately avoided re-creating items already in the DB from "Tiger sum · GS7 Ch4–6" and "GenSx Vol.1 Ch13 Spleen" (overlap list given to writers); spleen chapter kept small for that reason.

## What verification changed
Two independent reviewers answered all 50 MCQs blind — 50/50 agreed with keys. 36 scripted fixes:
- MUST: ESCAPE numbers (Izbicki 33 vs 51, 45% vs 20%, 51% crossover) are from the long-term follow-up (JAMA Surg), not JAMA 2020 (37 vs 49) — fixed in flashcard and CP MEQ. Spleen MEQ no longer lists atelectasis as a cause of POD 4 fever.
- FNA for suspected infected necrosis: "not mandatory" → ACG 2024 "suggest against routine FNA" (flashcard + AP MEQ).
- AP MEQ: BP 94/58 no longer called organ failure (modified Marshall needs ABG / fluid response); WATERFALL exclusion of moderately severe/severe noted; unstable pseudoaneurysm bleed → resuscitate + direct angiography/embolization (CTA only once stable; OR if IR unavailable).
- Splenic trauma MCQ stem now states IR is available; explanation cites WSES 2017. ITP MCQ cites the Aug 2026 ASH update (TPO-RA strong second line; ≥1-yr splenectomy delay kept as good practice).
- GSW trial-clamp stem no longer has an impossible pre-op CTA in an unstable patient.
- PDAC body tumour with celiac >180°: explanation notes current NCCN may call it borderline (modified Appleby) vs lecture "locally advanced" — key (EUS-FNA tissue) unchanged.
- MCN 5 cm key changed from "spleen-preserving distal pancreatectomy" to "distal pancreatectomy" (spleen preservation framed for <4 cm).
- Pseudocyst stem: "severe AP" → "interstitial edematous AP" (severe/necrotizing → WON). Gem-cap MCQ: vague PS → ECOG 2. POPF MCQ states amylase >3× ULN.
- Consent OSCE gained alternatives/consequences of declining; ward-review OSCE puts IV access + crossmatch before CTA. IPMN MEQ Q1 no longer uses duct communication before MRCP reveals it; Q5 changed to solid component (avoids duplicating the 7-mm nodule MCQ).
- Minor: divisum pancreatitis % labelled "per slide; others <5%"; POINTER 39% (NEJM 2021) vs ~35% long-term; MCN "มักไม่ต่อ MPD"; SCN card adds resection indications; AJCC stage III includes T4 any N.

## Known gaps — deliberately not tested
- Numbers flagged unverified in the summary: PNET 10–15%, PDAC share, infection risk by % necrosis, Thai gallstone proportion, 15–20 → 30-month survival, 10–20% 5-yr survival, accessory spleen %.
- Practice variation: somatostatin analogues for POPF, drains, neoadjuvant for resectable PDAC, EUS before upfront resection, MCN <4 cm observe vs resect, ITP platelet-transfusion timing, hyper-TG treatment, exact MPD cut-off for drainage (~6–7 mm).
- Not established by the lecture: AAST spleen grades, vaccine doses/schedules, antibiotic regimens, DGE grade details, venous resection, chyle leak.
- The lecture has little peri-op/complication content; POPF/PPH/DGE, splenic trauma NOM and step-up detail rest on the web-verified summary.
- Near-duplicates to watch: CP Frey MCQ ↔ CP MEQ (near-identical vignette); splenic blush MCQ ↔ spleen MEQ Q1–2; stump-fistula NAGMA MCQ ↔ Ch1 MEQ; BISAP 4 MCQ ↔ AP MEQ Q1; staging laparoscopy MCQ ↔ PDAC MEQ Q3; Kyoto 20–30 mm MCQ ↔ flashcard ↔ IPMN MEQ Q3.
- Overlap with "Tiger sum · GS7 Ch4–6" and "GenSx Vol.1 Ch13 Spleen" is by angle only (different Topic); filter by Topic to drill one lecture.

## Retiring this set
Filter `Topic LIKE 'Pancreas & Spleen (Kitisin)%'` (rows created after 2026-10-21 02:17:16Z). MCP cannot delete — move rows to a "🗑 ชุดเก่า" page under the Surgery course page.

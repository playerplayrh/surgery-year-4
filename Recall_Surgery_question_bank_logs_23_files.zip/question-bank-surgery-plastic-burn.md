# Question bank — Plastic & Burn (Recall Surgery)

**Run:** 2026-10-14 · **Source:** Basic Plastic Surgery (อ.เสรี เอี่ยมพงษ์ไสว) — lecture slides (2 annotated versions) via the verified summary PDF `basic_plastic_surgery_summary.pdf` · **Subject:** `Plastic & Burn` · **Status:** all `Ready` (0 Draft)

## Counts

| Topic | MCQ | Flashcard | MEQ | OSCE | Total |
|---|---|---|---|---|---|
| Basic Plastic Surgery (อ.เสรี) · Ch1 Incision, excision & suturing | 8 | 8 | 1 | 1 | 18 |
| Basic Plastic Surgery (อ.เสรี) · Ch2 Wound dressing | 5 | 5 | 1 | 1 | 12 |
| Basic Plastic Surgery (อ.เสรี) · Ch3 Skin graft, flap & reconstructive ladder | 7 | 7 | 1 | 0 | 15 |
| **Total** | **20** | **20** | **3** | **2** | **45** |

MCQ key spread: A 5 · B 4 · C 4 · D 3 · E 4. Notion SQL check: every MCQ has 5 choices + Correct + Explanation; every Flashcard/MEQ/OSCE has Answer; both OSCEs have Checklist + Minutes; 0 duplicate Names in the whole DB.

## Editorial rules applied
- MCQs fully English, USMLE/NL-style vignettes with vitals (stems 344–488 chars); lead-ins weighted to decisions (which technique/dressing/graft/flap, why a technique fails, most likely complication).
- Lecturer-only numbers are either attributed to the lecture or kept out of MCQ keys: tensile strength ~10% at 1 wk / near 80% at 6 wk, deep dermal hold ~6 wk, composite graft ≤1 cm, random flap 1:1 (face 1:3), FTSG primary contraction ~50%.
- Not tested (unverified in source): eye 5 / lip 6 aesthetic subunits, "PMDs" as a key, "silver > betadine" cytotoxicity ranking, the sulfa-allergy note.
- No exact suture-removal day used as an MCQ key (institution-dependent).
- No doses anywhere in the set.

## What adversarial review changed (20/20 MCQ keys independently confirmed; 0 critical)
- Ch1 MEQ: Vicryl/Monocryl "hold ~6 wk" reworded as the lecturer's figure (Monocryl loses most strength by 2 wk).
- Ch1 MCQ (layered closure): tensile-strength numbers attributed to the lecture.
- Ch1 OSCE: Name now states irrigation, neurovascular check and local anaesthesia are assumed done — the source doesn't teach those steps.
- Ch1 MCQs (vertical / horizontal mattress): removed "thin skin" cue that pointed at fragile-skin management.
- Ch1 flashcard: subcuticular runs in the upper dermis just below the dermoepidermal junction.
- Ch2 MEQ: removed an off-topic leg-perfusion clause from an abdominal wound scenario.
- Ch2 MCQ: shortened a distractor tied in length with the key.
- Ch3 MCQ (burn graft): dropped "tangential" (classically for deep partial-thickness burns).
- Ch3 MCQ (arterial flap compromise): explanation now says to notify the surgeon for re-exploration if loosening fails.
- Ch3 MEQ: ladder step now includes the regional rung.

## Known gaps (source didn't teach — not imported)
- Burns (TBSA, resuscitation formulas, escharotomy) — this lecture is basic plastic only; Plastic & Burn still has no burn items.
- Laceration work-up before suturing (irrigation, local anaesthetic choice/dose, tetanus) — OSCE assumes these done.
- Scar management after healing (silicone, pressure, steroid dosing), keloid adjuvant specifics.
- Flap monitoring frequency and named-flap anatomy (vessels of specific axial/free flaps).
